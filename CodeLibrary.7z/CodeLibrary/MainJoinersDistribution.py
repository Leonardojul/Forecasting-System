"""
IMPORT PYTHON LIBRARIES/MODULES
"""
import datetime
import os

import numpy as np
import pandas as pd
import yaml
import matplotlib.pyplot as plt

import helper_data_preparation as hdp
import helper_regression as hr
import helper_sarimax as sari
import helpers_statistical_evaluation as stat_eval
import helper_plots as plots
import helper_query_data_dwh as query_dwh

"""
JOINERS DISTRIBUTION
"""
### TO DO ###
# add comparison between Sk learn and Sarimax. Pick best model and use that distribution

# Determine environment
with open('environment.yml') as file:
    settings_yaml = yaml.load(file, Loader=yaml.FullLoader)
environment = settings_yaml.get('environment')
environment_push_data = settings_yaml.get('environment_push_data')

# Load settings
for x in ['settings_NL.yml', 'settings_BE.yml', 'settings_FR.yml', 'settings_ES.yml']:
    with open(x) as file:
        settings_yaml = yaml.load(file, Loader=yaml.FullLoader)
    country = settings_yaml.get('country')
    drop_campaigns = settings_yaml.get('features').get('drop_campaigns')
    gymClosure = settings_yaml.get('features').get('gymClosure')
    corona_dates_included = settings_yaml.get('features').get('corona_dates_included')
    print(f'Start forecasting on {country}')

    # LOAD Data
    # Latest Data from DWH
    query = settings_yaml.get('preprocess').get('query_view')
    query_criteria = settings_yaml.get('preprocess').get('query_criteria')

    data_queried = query_dwh.get_data(environment=environment, query=query, query_criteria=query_criteria)

    data = data_queried[data_queried.Country == country]
    data = hdp.add_holiday_col(data, date_col='Date', country=country)
    data['Campaign'] = 0
    data['Campaign'] = data.loc[data['Month'] == 9, 'Campaign'] = 1
    data['Campaign'] = data.loc[data['Month'] == 1, 'Campaign'] = 1

    # Choose dataset
    df = data.copy()
    df_filtered = df[df.Country == country]

    # Exploratory Data Analysis
    nulls = df.loc[(df['Joiners'].isna()) |
                   (df['OpenedClubs'].isna()) |
                   (df['RunningClubs'].isna()) |
                   (df['MatureClubs'].isna()) |
                   (df['Campaign'].isna()) |
                   (df['GymClosure'].isna())]

    if corona_dates_included != 'yes':
        df_filtered = df_filtered[df_filtered['GymClosure'] == 0]

    # Make date a datetime and sort.
    df_filtered['Date'] = pd.to_datetime(df_filtered['Date'])
    df_enriched = df_filtered.sort_values(by='Date')
    # Add maturity level
    df_enriched['MaturityLevel'] = df_enriched['MatureClubs'] / df_enriched['RunningClubs']
    df_enriched['MaturityLevel'] = df_enriched['MaturityLevel'].replace(np.nan, 0)

    # Adjust columns based on YAML files
    categorical_cols2dummy = settings_yaml.get('preprocess').get('categorical')
    binary_cols = settings_yaml.get('preprocess').get('binary')

    df_dummy = hdp.get_dummies_v2(df_enriched, categorical_cols2dummy)
    df_binary = hdp.make_binary(df_dummy, binary_cols)
    df_enriched = df_binary.copy()

    # add campaign table
    # TO DO integrate spreadsheet that will be used by Marketing
    # campaigns = pd.read_excel('Marketing_2018_current_v2.xlsx')
    # df_enriched = df_enriched.merge(campaigns.loc[:,['Date', f'{country}', f'{country}_sort_campaign',
    #                                                 # f'{country}_TV_radio', f'{country}_promo_code',
    #                                                  f'Countdown_{country}']].copy(), left_on='Date', right_on='Date')
    # df_enriched = df_enriched.drop(columns=['Campaign', f'{country}_sort_campaign']).rename(columns={f'{country}': 'Campaign'})
    # df_enriched.Campaign = df_enriched.Campaign.astype(int)
    # df_enriched[f'Countdown_{country}'] = df_enriched[f'Countdown_{country}'].replace({"no": 0, "No": 0,
    #                                                                                    "yes": 1, "Yes": 1})

    df_enriched.set_index('Date', inplace=True, drop=True)
    DatePlaceholder = df_enriched['CalendarKey']

    df_for_model = df_enriched.copy()

    # Find which cols to drop.
    cols_drop = settings_yaml.get('features').get('drop_cols')
    if drop_campaigns == 'yes':
        cols_drop.append('Campaign')
    if gymClosure != 'include':
        cols_drop.append('GymClosure')
    print(f'columns that are dropped for enriching: {cols_drop}')
    df_for_model = df_for_model.drop(columns=cols_drop)
    # Setting prerequisites
    target_col = settings_yaml.get('analysis').get('target_col')
    random_state = settings_yaml.get('analysis').get('random_state')

    X = df_for_model.copy()
    X = X.drop(columns=[target_col])
    y = pd.DataFrame(df_for_model[target_col].copy())

    historic_start = settings_yaml.get('timeframes').get('historic_start')

    # setting timeframes for Train & Test
    if settings_yaml.get('timeframes').get('prediction_period') == 'next_month':
        # No need to define End prediction here.
        historic_start = settings_yaml.get('timeframes').get('historic_start')
        historic_start, historic_end, prediction_start, prediction_end = hdp.create_periods(historic_start, '2022-06-01')
        print(f'Predictions are for next month. Using create periods function')
        test_timewise_start = settings_yaml.get('timeframes').get('test_timewise_start')
        test_timewise_end = settings_yaml.get('timeframes').get('test_timewise_end')

    if settings_yaml.get('timeframes').get('prediction_period') == 'manual':
        historic_start = settings_yaml.get('timeframes').get('historic_start')
        historic_end = settings_yaml.get('timeframes').get('historic_end')
        test_timewise_start = settings_yaml.get('timeframes').get('test_timewise_start')
        test_timewise_end = settings_yaml.get('timeframes').get('test_timewise_end')
        prediction_start = settings_yaml.get('timeframes').get('prediction_start')
        prediction_end = settings_yaml.get('timeframes').get('prediction_end')
        print(f'Prediction periods are set manually in YAML-file')
    else:
        print(f'Adjust value for prediction period in YAML-file. Currently using default: next_month')
        historic_start, historic_end, prediction_start, prediction_end = hdp.create_periods(historic_start, '2022-06-01')

    print(df_for_model.columns)
    variables = settings_yaml.get('analysis').get('variables')
    df_for_model = df_for_model.loc[:,variables].copy()


    #Set train/Test split based on random or timewise
    if settings_yaml.get('timeframes').get('train_test_method') == 'random':
 

        # Initially we test random with a split of 90-10. If Timewise testset must be created, then add.
        X_train, X_test, y_train, y_test = hr.split_data(df_for_model, target=target_col,
                                                         tr_start=historic_start, tr_end=historic_end,
                                                         test_size_dataset=0.1,
                                                         random_state=random_state)
        print(f'Train/Test period is : {historic_start} until {historic_end}')
        print(f'Prediction period is: {prediction_start} until {prediction_end} \n')
    elif settings_yaml.get('timeframes').get('train_test_method') == 'timewise':  # Timewise Train/Test split based on test period.
        X_train, X_test, y_train, y_test, \
        X_predict, y_predict = hdp.split_data_timewise(df=df_for_model,
                                                       target=target_col,
                                                       tr_start=historic_start,
                                                       tr_end=test_timewise_start,
                                                       test_start=test_timewise_start,
                                                       test_end=test_timewise_end,
                                                       pred_start=prediction_start,
                                                       pred_end=prediction_end)

        # X_train = X.loc[:test_timewise_start, :].copy()
        # y_train = y.loc[:test_timewise_start].copy()
        # X_test = X.loc[test_timewise_start:test_timewise_end, :].copy()
        # y_test = y.loc[test_timewise_start:test_timewise_end, :].copy()
        print(f'Train period is : {historic_start} until {test_timewise_start}')
        print(f'Test period is : {test_timewise_start} until {test_timewise_end}')
        print(f'Prediction period is: {prediction_start} until {prediction_end} \n')
    else:
        print(f'Value {settings_yaml.get("timeframes").get("train_test_method")} not valid for splitting the data. '
              f'Auto reset to random')
        X_train, X_test, y_train, y_test = hr.split_data(df_for_model, target=target_col,
                                                         tr_start=historic_start, tr_end=historic_end,
                                                         test_size_dataset=0.1,
                                                         random_state=random_state)

    X_train_timewise = X.loc[:historic_end, :].copy()
    y_train_timewise = y.loc[:historic_end].copy()
    X_test_timewise = X.loc[test_timewise_start:test_timewise_end, :].copy()
    y_test_timewise = y.loc[test_timewise_start:test_timewise_end, :].copy()

    y_pred = y.loc[prediction_start:prediction_end, :].copy()
    # set current time for saving files.
    current_time = datetime.datetime.now().strftime("%y%m%d_%H%M")

    # define models that should run
    run_models = settings_yaml.get('analysis').get('run_models')

    if len(run_models) == 0:
        print(f'No models to run')

    # SK-learn GradientBoostingRegression model
    if settings_yaml.get('analysis').get('sk-learn-regression').get('model_name') in run_models:
        print(f'Running model {settings_yaml.get("analysis").get("sk-learn-regression").get("model_name")}')

        hyper_parameters = settings_yaml.get('analysis').get('sk-learn-regression').get('hyperparameters')
        param, est, l_rate, max_d, model = hr.training_new(X_train, y_train, hyper_parameters,
                                                           random_state=random_state)

        cols = X_test.columns
        # Test with randomized or timewise test-set.
        y_predicted_sk = model.predict(X_test)
        sk_importance_, sk_stat_scores = stat_eval.statistical_evaluation(model,
                                                                          y_test,
                                                                          y_predicted_sk,
                                                                          features=cols)
        df_pred = hr.predict_values(df_for_model,
                                    prediction_start,
                                    prediction_end,
                                    country,
                                    DatePlaceholder,
                                    model,
                                    target_col=target_col)

        # Add the holiday column from df_for_model to df_pred based on Date index (left join)
        df_pred = df_pred.merge(df_for_model['Holiday'], on=['Date'], how='left')

        settings_sklearn = {"binary_colums": binary_cols,
                            "cat_columns": categorical_cols2dummy,
                            "corona_dates_included": corona_dates_included,
                            "drop_campaigns": drop_campaigns,
                            "start_pred": prediction_start,
                            "end_pred": prediction_end,
                            "R2_score": sk_stat_scores.get('R2_score'),
                            "NRMSE": sk_stat_scores.get('NRMSE'),
                            "MAE": sk_stat_scores.get('MAE'),
                            "MAPE": sk_stat_scores.get('MAPE')
                            }
        print(sk_importance_)
        print(settings_sklearn)

        model_overview_df = pd.DataFrame(settings_sklearn.items())

        # Save files
        dict_items = settings_sklearn.items()
        settings2 = dict(list(dict_items)[:3])
        file_name = ""
        for item in settings2:
            file_name += item + "_" + str(settings2[item]) + '_'

        # if settings_yaml.get('analysis').get('sk-learn-regression').get('save_model') == 'yes':
        #     os.chdir(os.getcwd())
        #     df_pred.to_csv(f'{current_time}-generated-datetime_{country}_skregression__predictions_{file_name}.csv')
        #     model_overview_df.to_csv(f'{current_time}_generated_datetime_{country}_skregression_overview_results_{file_name}.csv')
        #
        # if settings_yaml.get('analysis').get('sk-learn-regression').get('plot_predictions') == 'yes':
        #     y_pred = y.loc[prediction_start:prediction_end, :].copy()
        #     plots.plot_fc_sklearn_regression(y_pred, df_pred, country=country)
        #
        # if settings_yaml.get('analysis').get('sk-learn-regression').get('plot_features') == 'yes':
        #     plots.plot_feature_importance_sklearn(model, sk_importance_, country=country)
        #
        # plt.figure()
        # plt.plot(df_pred.index, df_pred.Distribution)
        # plt.title(f'Joiners Distribution for {country} ')
        # plt.xticks(rotation=90)
        # plt.show()

        if 'save_location_dwh' in settings_yaml.get('analysis').get('sk-learn-regression'):
            save_location = settings_yaml.get('analysis').get('sk-learn-regression').get('save_location_dwh')

            # Add cureent_time to resultset which is written to the DWH
            current_time = str(datetime.datetime.now())
            df_pred['VersionTime'] = current_time

            # Saves Version as well in the function
            post_data_in_dwh = query_dwh.post_data_table(environment=environment_push_data,
                                                         table_name_dwh=save_location,
                                                         col_names=df_pred.columns,
                                                         df=df_pred)

            statsLog = pd.DataFrame([current_time,
                                     country,
                                     len(df_pred),
                                     sk_stat_scores.get('R2_score'),
                                     sk_stat_scores.get('NRMSE'),
                                     sk_stat_scores.get('MAE'),
                                     sk_stat_scores.get('MAPE'),
                                     str(settings_yaml)
                                     ]).T

            stats_cols = ['VersionTime', 'Country', 'LengthPredictions', 'R2score', 'NRMSE', 'MAE', 'MAPE', 'YAML_settings']
            statsLog.columns = stats_cols
            post_statsLog = query_dwh.post_data_table(environment=environment_push_data,
                                                 table_name_dwh='tgt.StatsLogJoiners',
                                                 col_names=statsLog.columns,
                                                 df=statsLog)

        print(f'Total predicted Joiners SK learn: {int(df_pred.prediction_values.sum())}')

    ## SARIMAX ###
    if settings_yaml.get('analysis').get('sarimax').get('model_name') in run_models:
        print(f'Running model {settings_yaml.get("analysis").get("sarimax").get("model_name")}.. \n')
        order = tuple(settings_yaml.get('analysis').get('sarimax').get('order'))
        seasonal_order = tuple(settings_yaml.get('analysis').get('sarimax').get('seasonal_order'))
        iterations = settings_yaml.get('analysis').get('sarimax').get('iterations')
        alpha = settings_yaml.get('analysis').get('sarimax').get('statistics').get('alpha')
        CI = 1 - alpha

        # y_train.index = pd.DatetimeIndex(y_train.index).to_period('D')
        # y_train = y_train.sort_index()
        # X_train.index = pd.DatetimeIndex(X_train.index).to_period('D')
        # X_train = X_train.sort_index()

        # Train Model

        sari_model_trained = sari.train_sarima(y=y_train_timewise,
                                               X=X_train_timewise,
                                               order=order,
                                               seasonal_order=seasonal_order,
                                               iterations=iterations,
                                               method='powell',
                                               random_state=random_state,
                                               )
        #get amount of steps for timewise prediction
        steps = len(X_test)
        # Test model (done on X_test, since we don't want to test on prediction period.).
        # Keep in mind, testing should ideally be done timewise.
        sari_test_mean, sari_test_total = sari.sarimax_forecast(sari_model_trained,
                                                                exog=X_test_timewise,
                                                                steps=len(X_test_timewise),
                                                                alpha=alpha,
                                                                random_state=random_state)

        cols = X_test.columns
        sari_importances, sari_settings_scores = stat_eval.statistical_evaluation(sari_model_trained,
                                                                                  y_test_timewise,
                                                                                  sari_test_mean,
                                                                                  features=cols)

        settings = {"binary_columns": binary_cols,
                    "categorical_columns": categorical_cols2dummy,
                    "corona_dates_included": corona_dates_included,
                    "drop_campaigns": drop_campaigns,
                    "order": list(order),
                    "seasonal_order": list(seasonal_order),
                    "start_pred": X_test.index[0],
                    "end_pred": X_test.index[-1],
                    "R2_score": sari_settings_scores.get('R2_score'),
                    "NRMSE": sari_settings_scores.get('NRMSE'),
                    "MAE": sari_settings_scores.get('MAE'),
                    "MAPE": sari_settings_scores.get('MAPE')
                    }
        X_sarimax = X.loc[prediction_start:prediction_end, :].copy()
        y_sarimax = y.loc[prediction_start:prediction_end, :].copy()
        # X_test = X.loc[test_timewise_start:test_timewise_end, :].copy()
        # y_test = y.loc[test_timewise_start:test_timewise_end, :].copy()

        df_for_model.copy()
        # Create FC next month.

        X_sari_pred = X[prediction_start:prediction_end].copy()
        y_sari_pred = X[prediction_start:prediction_end].copy()

        sari_forecast_mean, sari_forecast_total = sari.sarimax_forecast(sari_model_trained,
                                                                        exog=X_sari_pred,
                                                                        steps=len(X_sari_pred),
                                                                        alpha=alpha,
                                                                        random_state=random_state)
        sari_forecast_total['country'] = country

        settings_excel = pd.DataFrame(settings.items(), columns=['key', 'value'])
        print(settings_excel)
        print(f'{country} is done .. \n\n')

        settings2 = dict(list(settings.items())[:3])
        file_name = ""
        for item in settings2:
            file_name += item + "_" + str(settings2[item]) + '_'
        if settings_yaml.get('analysis').get('sarimax').get('save_model') == 'yes':
            os.chdir(os.getcwd())
            sari_forecast_total.to_csv(f'{current_time}_generated_datetime_{country}_sarimax_predictions_{file_name}latest.csv')
            settings_excel.to_csv(f'{current_time}_generated_datetime_{country}_sarimax_overview_results_{file_name}latest.csv')


        if 'save_location_dwh' in settings_yaml.get('analysis').get('sarimax'):
            save_location = settings_yaml.get('analysis').get('sarimax').get('save_location_dwh')
        df_for_dwh = pd.DataFrame(data=None, columns=['Distribution', 'CountryISO', 'prediction_values', 'DateKey'])
        df_for_dwh['Distribution'] = sari_forecast_total['mean'] / sari_forecast_total['mean'].sum()
        df_for_dwh['CountryISO'] = country
        df_for_dwh['PredictionValues'] = sari_forecast_total['mean']
        df_for_dwh['VersionTime'] = str(datetime.datetime.now())
        df_for_dwh['Date'] = pd.date_range(prediction_start, prediction_end, freq = 'D').tolist()
        # df_for_dwh = df_for_dwh.reset_index()
        df_for_dwh.set_index('Date', inplace=True, drop=True)
        df_for_dwh = df_for_dwh.merge(df_for_model['Holiday'], on=['Date'], how='left')
        df_for_dwh = df_for_dwh[['Distribution', 'CountryISO', 'PredictionValues', 'Holiday', 'VersionTime']]

        print(df_for_dwh)
        if settings_yaml.get('analysis').get('sarimax').get('plot_predictions') == 'yes':
            # Plot the Sarima forecast vs Real
            plots.sarimax_plot_real_vs_fc(y_sarimax,
                                          sari_forecast_total,
                                          start=prediction_start,
                                          end=prediction_end,
                                          country=country,
                                          plot_CI=True,
                                          CI=CI)

            sari_distribution = sari.get_distribution(sari_forecast_mean,
                                                      prediction_start,
                                                      prediction_end,
                                                      country,
                                                      dates=list(y_sari_pred.index))

            y_real_distribution = sari.get_distribution(y_sari_pred,
                                                        prediction_start,
                                                        prediction_end,
                                                        country,
                                                    dates=list(y_sarimax.index))

        plt.plot(sari_distribution.index, sari_distribution['mean'])
        plt.plot(y_real_distribution.index, y_real_distribution['mean'])
        plt.xticks(rotation=90)
        plt.show()
        # per_month_sari = sari_forecast_total['mean'].groupby()
        pred_per_month = int(pd.DataFrame([np.round(x[1]['mean'].sum(), 0) for x
                                           in sari_forecast_total.groupby(pd.Grouper(freq='M'))]).iloc[0])
        real_per_month = int(pd.DataFrame([x[1].sum() for x in y_sarimax.groupby(pd.Grouper(freq='M'))]).iloc[0])
        print(f'values predicted per month from on {sari_forecast_total.index[0]}: {pred_per_month}')
        print(f'real values per month from on {y_sarimax.index[0]}: {real_per_month}')
        print(f'real values per month from on {y_test_timewise.index[0]}: {real_per_month}')
        print(dict(zip(pred_per_month, real_per_month)))
        print(sari_forecast_total['mean'].sum())
        print(y_test_timewise.sum())
