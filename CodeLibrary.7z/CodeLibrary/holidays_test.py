import holidays

a = holidays.country_holidays('NL', years=2023)

print(a)