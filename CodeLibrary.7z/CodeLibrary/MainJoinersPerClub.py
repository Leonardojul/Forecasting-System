import datetime

import numpy as np
import pandas as pd
import yaml
import matplotlib.pyplot as plt

import helper_data_preparation as hdp
import helper_regression as hr
import helper_sarimax as sari
import helpers_statistical_evaluation as stat_eval
import helper_plots as plots
import helper_query_data_dwh as query_dwh


"""
JOINERS PER CLUB
"""
# Determine environment
with open('environment.yml') as file:
    settings_yaml = yaml.load(file, Loader=yaml.FullLoader)
environment = settings_yaml.get('environment')
environment_push_data = settings_yaml.get('environment_push_data')

# Load settings
for x in ['settings_NL.yml', 'settings_BE.yml', 'settings_FR.yml', 'settings_ES.yml']:
    with open(x) as file:
        settings_yaml = yaml.load(file, Loader=yaml.FullLoader)
    country = settings_yaml.get('country')

    print(f'Start forecasting on {country}')

    # LOAD Data
    # Latest Data from DWH
    query = settings_yaml.get('preprocess').get('query_view_clubs')
    query_criteria = settings_yaml.get('preprocess').get('query_criteria')

    data_queried = query_dwh.get_data(environment=environment, query=query, query_criteria=query_criteria)

    data = data_queried.copy()
    data['Date'] = pd.to_datetime(data.loc[:, 'Date'])

    mask = (data.Date > '2022-06-01') & (data.Country.isna())
    df_empty = data.loc[mask, :].copy()

    data['Campaign'] = 0
    data['Campaign'] = data.loc[data['Month'] == 9, 'Campaign'] = 1
    data['Campaign'] = data.loc[data.loc[:, 'Month'] == 1, 'Campaign'] = 1
    data = data[data.Country == country]
    data = data[data.ClubKey > 0]

    df_enriched = data.sort_values(by='Date')
    df_enriched.set_index('Date', inplace=True, drop=True)
    df_for_model = df_enriched.copy()
    # df_for_model = df_for_model.loc[df_for_model.Maturity != 'NewClub']
    df_for_model['Maturity'] = df_for_model['Maturity'].replace({'Immature': 0, 'Mature': 1, 'NewClub': 2})

    df_for_model = df_for_model[df_for_model['GymClosure'] == 0]
    df_for_model = df_for_model[df_for_model['ClubClosureDate'].isnull()]
    df_for_model = df_for_model.drop(columns=['ClubOpeningsDate', 'Country', 'GymClosure'])


    print(f'Amount of new clubs:{len(df_for_model.loc[df_for_model.Maturity == "NewClub","ClubKey"].unique())}')
    # setting timeframes for Train & Test
    # using all data for X and Y
    if settings_yaml.get('timeframes').get('prediction_period') == 'next_month':
        # No need to define End prediction here.
        historic_start, historic_end, prediction_start, prediction_end = hdp.create_periods('2018-01-01', '2022-06-01')
        print(f'Predictions are for next month. Using create periods function')
    if settings_yaml.get('timeframes').get('prediction_period') == 'manual':
        historic_start = settings_yaml.get('timeframes').get('historic_start')
        historic_end = settings_yaml.get('timeframes').get('historic_end')
        test_timewise_start = settings_yaml.get('timeframes').get('test_timewise_start')
        test_timewise_end = settings_yaml.get('timeframes').get('test_timewise_end')
        prediction_start = settings_yaml.get('timeframes').get('prediction_start')
        prediction_end = settings_yaml.get('timeframes').get('prediction_end')
        print(f'Prediction periods are set manually in YAML-file')
    else:
        print(f'Adjust value for prediction period in YAML-file. Currently using default: next_month')
        historic_start, historic_end, prediction_start, prediction_end = hdp.create_periods('2018-01-01', '2022-06-01')

    # Train test split sk learn
    target_col = 'JoinersClub'
    random_state = settings_yaml.get('analysis').get('random_state')

    clubs = list(set(df_for_model.ClubKey))
    list_df_clubs = []
    for club in clubs:
        df_club = df_for_model[df_for_model.loc[:, 'ClubKey'] == club]
        list_df_clubs.append(df_club)

    current_time = datetime.datetime.now()
    print(f'Running model {settings_yaml.get("analysis").get("sk-learn-regression").get("model_name")}')
    print(f'Amount of clubs in {country} : {len(list_df_clubs)}')

    #Set dates for upcoming year. and create empty df.
    next_y = datetime.datetime.now() + datetime.timedelta(weeks=60)
    df_dates = pd.DataFrame(pd.date_range(start=historic_start, end=next_y))
    df_dates.columns = ['Dates']
    df_dates = hdp.add_holiday_col(df_dates, date_col='Dates', country=country)
    df_dates = hdp.make_binary(df=df_dates, cols=['Holiday'])

    #Add holidays to DF
    print(f'Creating a holiday count on monthly basis for {country}')
    df_months = [x[1] for x in df_dates.groupby([df_dates.Dates.dt.year, df_dates.Dates.dt.month])]
    count_hol = []
    for x in df_months:
        hol_df = pd.DataFrame(x, columns =['Dates', 'Holiday'])
        hol_df.set_index('Dates', inplace=True, drop=True)
        count = hol_df.Holiday.sum()
        count_hol.append([hol_df.last_valid_index(), count])
    holiday_counts = pd.DataFrame.from_records(count_hol)
    holiday_counts.columns = ['Dates', 'Holiday']
    holiday_counts.set_index('Dates', inplace=True, drop=True)

    #loop over club and make a prediction
    clubJoinersMonth = []
    for club in list_df_clubs:
        club = club.merge(holiday_counts, how='left', left_index=True, right_index=True)
        KeyClub = club.ClubKey[0]
        print(f'Length of DF: {len(club)}')
        if len(club) < 10:
            print(f'New Club {club.ClubKey[0]}')
            pass
        try:
            #set dummy dataframe for FC.
            CloseDate = club['ClubClosureDate'][-1]
            dummy_df = df_empty.copy().reset_index(drop=True)
            dummy_df = dummy_df.drop(columns=['ClubClosureDate', 'ClubOpeningsDate', 'Country'])
            dummy_df['JoinersClub'] = 0
            dummy_df.ClubKey = KeyClub
            print(f'Forecasting for club {int(KeyClub)} located in {country}')
            OpenDate = df_enriched.loc[df_enriched.ClubKey == club.ClubKey[0]]['ClubOpeningsDate'][0]

            #add variables for respective club.
            dummy_df['YearsOpen'] = [x.date().year - OpenDate.year for x in dummy_df.Date]
            for x in dummy_df.YearsOpen:
                if x <= 2:
                    dummy_df.Maturity = 2
                elif x >= 4:
                    dummy_df.Maturity = 1
                else:
                    dummy_df.Maturity = 0
            # dummy_df.Maturity = [1 if x> 4 else 0 for x in dummy_df.YearsOpen]
            dummy_df = dummy_df.drop(columns=['GymClosure'])
            dummy_df['Campaign'] = 0
            dummy_df['Campaign'] = dummy_df.loc[dummy_df['Month'] == 9, 'Campaign'] = 1
            dummy_df['Campaign'] = dummy_df.loc[dummy_df.loc[:, 'Month'] == 1, 'Campaign'] = 1
            DatePlaceholder = dummy_df.Date
            dummy_df.set_index('Date', inplace=True, drop=True)
            dummy_df = dummy_df.merge(holiday_counts, how='left', left_index=True, right_index=True)

            club = club.drop(columns=['ClubKey', 'ClubClosureDate'])
            df_total = pd.concat([club, dummy_df])
            df_total = df_total.sort_index()

            X = df_total.copy()
            X = X.drop(columns=[target_col, 'ClubKey'])
            y = pd.DataFrame(df_total[target_col].copy())

            # Initially we test random with a split of 90-10. If Timewise testset must be created, then add.
            X_train, X_test, y_train, y_test = hr.split_data(club, target=target_col,
                                                             tr_start=historic_start, tr_end=historic_end,
                                                             test_size_dataset=0.15,
                                                             random_state=random_state)

            hyper_parameters = settings_yaml.get('analysis').get('sk-learn-regression').get('hyperparameters')
            param, est, l_rate, max_d, model = hr.training_new(X_train,
                                                               y_train,
                                                               hyper_parameters,
                                                               random_state=random_state)
            cols = X_test.columns
            # Test model
            y_predicted_sk = model.predict(X_test)
            y_predicted_total = model.predict(club.drop(columns=[target_col]))

            sk_importance_, sk_stat_scores = stat_eval.statistical_evaluation(model,
                                                                              y_test,
                                                                              y_predicted_sk,
                                                                              features=cols)
            print(sk_importance_)
            print(sk_stat_scores)
            # create DF prediction for the specific club
            df_pred = hr.predict_club_joiners_month(model, X, prediction_start, KeyClub)
            df_pred['Maturity'] = club.Maturity[-1]
            df_pred['Maturity'] = df_pred['Maturity'].replace({0: 'Immature', 1: 'Mature', 2: 'NewClub'})
            # df_pred['VersionTime'] = current_time
            df_pred['ClosingDate'] = CloseDate
            df_pred['R2_score'] = np.round(sk_stat_scores.get('R2_score'),8)
            df_pred['NRMSE'] = np.round(sk_stat_scores.get('NRMSE'),8)
            df_pred['MAE'] = np.round(sk_stat_scores.get('MAE'),8)
            df_pred['MAPE'] = np.round(sk_stat_scores.get('MAPE'),8)
            df_pred['Date'] = df_pred.index
            df_pred= df_pred[['Date', 'JoinersMonth', 'ClubKey', 'Maturity', 'ClosingDate',
           'R2_score', 'NRMSE', 'MAE', 'MAPE']]

            clubJoinersMonth.append(df_pred)
            # plot
            # plt.figure()
            # plt.xticks(rotation=90)
            # plt.plot(club.index, club[f'{target_col}'], 'b')
            # plt.plot(df_pred.index, df_pred['JoinersMonth'], 'k-')
            # plt.scatter(y_test.index, y_predicted_sk, c='r', marker='^')
            # plt.plot(club.index, y_predicted_total, 'g-', alpha=0.6)
            # plt.legend(['Real_values', 'prediction_values', 'test_values', 'Predicted_total'])
            # plt.ylabel('Joiners')
            # plt.title(f'Joiners for club {int(KeyClub)} in country {country}')
            # plt.show()

            print(f"Done for club {KeyClub} \n\n")
        except ValueError:
            print(f'No predictions for club {KeyClub}')
            pass
    clubJoinersMonth2 = pd.concat(clubJoinersMonth)
    clubJoinersMonth2['JoinersMonth'] = np.round(clubJoinersMonth2['JoinersMonth'].fillna(0),8)

    clubJoinersMonth2['R2_score'] = clubJoinersMonth2['R2_score'].fillna(0)
    clubJoinersMonth2['MAE'] = clubJoinersMonth2['MAE'].fillna(0)
    clubJoinersMonth2['NRMSE'] = clubJoinersMonth2['NRMSE'].fillna(0)
    clubJoinersMonth2['MAE'] = clubJoinersMonth2['MAE'].fillna(0)
    clubJoinersMonth2['MAPE'] = clubJoinersMonth2['MAPE'].fillna(0)

    mask = clubJoinersMonth2.Maturity == 'Immature'
    clubJoinersMonth2.loc[mask , ['R2_score','NRMSE']] = 0

    mask = clubJoinersMonth2.Maturity == 'NewClub'
    clubJoinersMonth2.loc[mask, ['R2_score', 'NRMSE']] = 0

    clubJoinersMonth2.to_excel(f'ClubJoinersMonth_{country}.xlsx')
    save_location = 'tgt.ClubsJoinersMonthPredicted'

    # Saves Version as well in the function
    post_data_in_dwh = query_dwh.post_data_table(environment=environment_push_data,
                                                 table_name_dwh=save_location,
                                                 col_names=df_pred.columns,
                                                 df=clubJoinersMonth2)


    print(len(list_df_clubs))
