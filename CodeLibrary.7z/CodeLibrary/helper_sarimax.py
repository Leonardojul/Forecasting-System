import pandas as pd
import datetime

import statsmodels.api as sm
from statsmodels.tsa.statespace.sarimax import SARIMAX

from pmdarima.arima import auto_arima

def auto_sarimax(training_set: pd.DataFrame,
                 p_arima: int,
                 q_arima: int,
                 P_arima: int,
                 Q_arima: int,
                 seasonality: int,
                 freq: str):
    """
    Runs a sarimax fitting for values from 0 to x for p, q, P and Q, calculates AIC and BIC values for each
    momdel configration and retuns all results in a single dataframe for easy comparison

    Args:
        training_set (pd.DataFrame): Single-column dataset to be analyzed.
        p_arima (int): Autoregressive (AR) component of model expressed in order p
        q_arima (int): Moving average (MA) component of model expressed in order q
        P_arima (int): Seasonal autoregressive (SAR) component of model expressed in order P
        Q_arima (int): Seasonal moving average (SMA) component of model expressed in order Q
        seasonality (int): Length of the repeating periods expressed in units of 'freq'
        freq (str): Unit of the seasonality frequency, can be D for Days, W for Weeks, M for Months and Y for Years

    Returns:
        order_df (pd.DataFrame): Dataframe with all combinations of parameters, along with their AIC and BIC scores

    """
    # Create empty list to store search results
    order_aic_bic = []
    training_set_ = training_set.copy()

    if freq not in ["D", "W", "M", "Y"]:
        return "Wrong frequency indication Please use any the following options: D,W,M,Y"
    
    # Loop over p values
    for p in range(p_arima):
        # Loop over q values
        for q in range(q_arima):

            # create and fit ARMA(p,q) model
            for P in range(P_arima):
                for Q in range(Q_arima):
                    model = SARIMAX(training_set_, order=(p, 1, q), seasonal_order=(P, 1, Q, seasonality), freq=freq)
                    results = model.fit()
                    # Append order and results tuple
                    order_aic_bic.append((p, q, P, Q, results.aic, results.bic))
                    print("Calculated with p= ", p, " q= ", q, " P= ", P, " Q= ", Q)

    # Construct DataFrame from order_aic_bic
    order_df = pd.DataFrame(order_aic_bic,
                            columns=['p', 'q', 'P', 'Q', 'AIC', 'BIC'])
    return order_df

def get_auto_arima(y: pd.DataFrame, X: pd.DataFrame,
                   m=7, d= 1,
                   start_p=0, start_q=0,
                   max_p=2, max_q=2,
                   start_P=0, max_Q=1,
                   max_P=2, max_D=2,
                   D=1, trace=True,
                   error_action= 'ignore',
                   suppress_warnings=True,
                   stepwise=True
                   ):
    """

    Args:
        y: df, the output
        X: df, exogenous factors
        test: str, options ['adf', 'kpss', 'pp']
        m: int, the  period for seasonal differencing (in JoinersDistribution = 7 mostly).
        d: int, the order of first differencing. Value will be automatically selected based on the results of test.
        start_p: int, order of the auto regressive model (AR) must be positive.
        start_q: int, order of the movig average (MA) must be positive.
        max_p: maximum value of p, default = 5, positive int,>= start_p
        max_q: maximum value of q, default = 5, positive int,> start_q
        start_P: int, The starting value of P, the order of the auto-regressive portion of the seasonal model.
        max_Q: int, The maximum value of Q, inclusive. Must be a positive integer greater than start_Q.
        max_P: int, The maximum value of P, inclusive. Must be a positive integer greater than start_P.
        max_D: int, The maximum value of D. Must be a positive integer greater than D.
        D: int, The order of the seasonal differencing.
        trace:
        error_action:
        suppress_warnings:
        stepwise:

    Returns:
        model_output: the model
        params_best_model: dict, the parameters for the model
        order: list, the orders for the ARIMA model
        seasonal_order: list, the seasonality orders for the best fitting model
    """
    model_output = auto_arima(y, X,
                              start_p=start_p, start_q=start_q,
                              test='adf',
                              max_p=max_p, max_q=max_q,
                              m=m,
                              d=d,
                              start_P=start_P,
                              max_Q=max_Q,
                              max_P=max_P,
                              max_D=max_D,
                              D=D,
                              trace=trace,
                              error_action=error_action,
                              suppress_warnings=suppress_warnings,
                              stepwise=stepwise)
    order = list(model_output.get_params().get('order'))
    seas_order = list(model_output.get_params().get('seasonal_order'))
    params_best_model = model_output.get_params()

    return model_output, params_best_model, order, seas_order

def train_sarima(
        y: pd.DataFrame,
        X: pd.DataFrame,
        order: tuple,
        seasonal_order: tuple or list,
        iterations: int, method: str,
        random_state : int,
        ):
    """
    Args:
        y:
        X:
        order: tuple(3 values), The (p,d,q) order of the model for the number of AR parameters, differences, and MA parameters
        seasonal_order: tuple(4 values), The (P,D,Q,s) order of the seasonal component of the model for the AR parameters, differences, MA parameters, and periodicity
        iterations:
        method: str, optional, default Powell,
                options ['newton', 'nm', 'bfgs', 'lbfgs', 'power', 'cg', 'ncg', basinhoppping']
        random_state:
        trend:

    Returns:
        model_: the fitted model
    Exaple:

        .. code-block:: python

        train_sarima(y=y_train,X=X_train, order=order, seasonal_order=seasonal_order,iterations=iterations,
        method='powell',random_state = random_state, trend= 'with_intercept')
    """
    y_new = y.copy()
    X_Exog = X.copy()

    model_ = sm.tsa.statespace.SARIMAX(y_new,
                                       exog=X_Exog,
                                       order=order,
                                       seasonal_order=seasonal_order, random_state = random_state
                                       ).fit(max_iter=iterations, method='powell')

    return model_

def sarimax_predict(model,
                    X_test: pd.DataFrame,
                    start_date: str,
                    end_date: str,
                    alpha: float):
    """

    Args:
        model: Model created with the sarimax.fit function
        X_test: 
        start_date:
        end_date:
        summary:
        alpha:

    Returns:

    """

    output = model.predict(exog=X_test,
                           start=start_date,
                           end=end_date).summary_frame(alpha=alpha)

    return output

def sarimax_fit(train: pd.DataFrame,
                p_arima: int = 0,
                d_arima: int = 0,
                q_arima: int = 1,
                P_arima: int = 1,
                D_arima: int = 0,
                Q_arima: int = 1):
    """
    Fits the training data to the Sarimax model

    Args:
        train (pd.DataFrame): Single-column dataset to be fit
        p_arima (int): Autoregressive (AR) component of model expressed in order p
        d_arima (int): Integrating (I) component of model expressed in order d (diferencing)
        q_arima (int): Moving average (MA) component of model expressed in order q
        P_arima (int): Seasonal autoregressive (SAR) component of model expressed in order P
        D_arima (int): Seasonal integrating (SI) component of model expressed in order D (Diferencing)
        Q_arima (int): Seasonal moving average (SMA) component of model expressed in order Q


    Returns:
        Forecasting model

    Example:

        .. code-block:: python

            import pandas as pd
            test_data = {'Daily_volumes':[1,2,3,2,1,2,3,2,1,2,3,2,1,2,3,2,1,2,3,2,1,2,3]}
            date_generated = pd.date_range(start='1/1/2022',end='1/23/2022')
            test_dataframe = pd.DataFrame(test_data, index=date_generated)
            sarimax_fit(test_dataframe)

    """
    #The parameters for the sarimax model have been previously obtained from AIC and BIC comparisons on an interative process
    return sm.tsa.statespace.SARIMAX(train, exog = None, order = (p_arima,d_arima,q_arima),
                                     seasonal_order = (P_arima,D_arima,Q_arima,7),
                                     enforce_stationarity=False, enforce_invertibility=False).fit(disp = False)

def sarimax_fit_with_exog(train: pd.DataFrame,
                exog: pd.DataFrame,
                p_arima: int = 0,
                d_arima: int = 0,
                q_arima: int = 1,
                P_arima: int = 1,
                D_arima: int = 0,
                Q_arima: int = 1):
    """
    Fits the training data to the Sarimax model
    Args:
        train: training dataframe
    Returns:
        Forecasting model
        Exaple:

        .. code-block:: python

    import pandas as pd
    test_data = {'Daily_volumes':[1,2,3,2,1,2,3,2,1,2,3,2,1,2,3,2,1,2,3,2,1,2,3]}
    date_generated = pd.date_range(start='1/1/2022',end='1/23/2022')
    test_dataframe = pd.DataFrame(test_data, index=date_generated)
    sarimax_fit(test_dataframe)
    """
    #The parameters for the sarimax model have been previously obtained from AIC and BIC comparisons on an interative process

    model = sm.tsa.statespace.SARIMAX(endog = train, exog = exog, order = (p_arima,d_arima,q_arima), seasonal_order = (P_arima,D_arima,Q_arima,7),enforce_stationarity=False, enforce_invertibility=False)
    
    return model.fit(disp = False)


def sarimax_predictv2(sarimax_model, start: pd.Timestamp, end: pd.Timestamp, col_name: str):
    """
    Produces a prediction outside of the training data, from [start] to [end]

    Args:
        sarimax_model: The sarimax model to be used
        start (pd.Timestamp): Date from where to start predicting
        end (pd.Timestamp): Date until predictions should be produced
        col_name (str): The name of the column in the original dataframe to be used for the prediction

    Returns:
        prediction_sx (pd.DataFrame): Prediction in a dataframe
    """
    prediction_sx = pd.DataFrame(sarimax_model.predict(start=start, end=end))
    
    prediction_sx.columns = [col_name]

    return prediction_sx

def sarimax_predictv2_with_exog(sarimax_model,exog:pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp, col_name: str):
    """
    Produces a prediction outside of the training data, from start to end
    Args:
        sarimax_model: the sarimax model to be used
        start: number of records to be forecasted
        col_name: the name of the column in the original dataframe to be used for the prediction
    Returns:
        Prediction in a dataframe
    """
    prediction_sx = pd.DataFrame(sarimax_model.predict(start=start, end=end, exog = exog))

    prediction_sx.columns = [col_name]

    return prediction_sx

def sarimax_forecast(model,
                     exog: pd.DataFrame,
                     steps: int ,
                     alpha: float,
                     random_state = 42
                    ):
    """
    Function that makes an forecast using the given sarimax model. 
        Forecasts on the datetime index level and returns an df with the confidence intervals.
        
    Args:
        model: the best model coming from train arima. 
            Order and seasonal order are determined by auto_arima or by business knowledge.
        exog: pd.DataFrame, the dataframe with the feature_variables that can influence the Y-variable
        step: int, the length of the forecast (in days/weeks, depending on the data-frequency).
        alpha: float, the p-value, how well we should predict. Example .05 means that we have a 95% Confidence Interval. .2 --> 80% CI.
    Returns:  
        model_output: pd.DataFrame, the dataframe with index the date frequency and columns ['mean', 'se', 'ci_lower', 'ci_upper']  
    Exaple:

        .. code-block:: python

        Be aware that X_test comes from the split_data function.
        sarimax_forecast(sari_model_trained,exog=X_test, steps=len(X_test),alpha=alpha)
    """
    model_ = model
    random_state = random_state
    model_output_total = model_.get_forecast(exog = exog,
                                             steps = steps,
                                             dynamic = True,
                                             measurement_errorbool = True,
                                             ime_varying_regression = True,
                                             random_state = random_state).summary_frame(alpha = alpha)

    model_output_mean = model_output_total.loc[:,'mean']
    model_output_total.index = exog.index

    return model_output_mean, model_output_total

def get_distribution(df_pred: pd.DataFrame, start_prediction: str, end_prediction: str, country: str, dates: list):
    """
    Args:
        df_pred: pd.DataFrame, containing the predictions in real numbers.
        start_prediction: string, the string with the cut-off date that the prediction set should start.
        end_prediction: string, the string with the cut-off date that the prediction set should end.
        country: the country that we make the predictions for (used for filtering)
        #DatePlaceholder: the dates we need to make the predictions for.
        #model: the best model based on the GradientBoostingRegressor from the training set(!)
    Returns
         df_pred_norm: pd.DataFrame, the predictions (in % of total per month) for the upcoming month (fixed at the moment) based on the best regressor.
    """
    df_new = df_pred.copy()
    df_new.index = dates
    df_new = df_new[start_prediction:end_prediction]
    total_pred = df_new.sum()

    prediction_distribution = df_new / total_pred
    df_pred_ = pd.DataFrame(index=df_new.index, data=prediction_distribution)
    df_pred_.columns =['mean']
    df_pred_['country'] = country

    return df_pred_

def create_dwh_df(df: pd.DataFrame, country_str: str, start_pred: str, end_pred:str, df_holiday: pd.DataFrame):
    """

    Args:
        df: pd.DataFrame, with the total forecast of the sarimax model
        country_str: string of the country we are predicting
        start_pred: str, the start date of the prediction
        end_pred: str, the end date of the prediction
        df_holiday: pd.Dataframe, the column containing the holiday-dates in the specific country.

    Returns:
        df_for_dwh: a df that contains all the information that should be inserted into the DWH-table.
    Exaple:

        .. code-block:: python


    """
    cols = ['Distribution', 'CountryISO', 'prediction_values', 'DateKey']
    df_new = df.copy()
    df_for_dwh = pd.DataFrame(data=None, columns=cols)
    df_for_dwh['Distribution'] = df_new['mean'] / df_new['mean'].sum()
    df_for_dwh['CountryISO'] = country_str
    df_for_dwh['PredictionValues'] = df_new['mean']
    df_for_dwh['VersionTime'] = str(datetime.datetime.now())
    df_for_dwh['Date'] = pd.date_range(start_pred, end_pred, freq='D').tolist()
    df_for_dwh['DateKey'] = [x.strftime('%Y%m%d') for x in df_for_dwh['Date']]
    df_for_dwh.set_index('Date', inplace=True, drop=True)
    df_for_dwh = df_for_dwh.merge(df_holiday['Holiday'], on=['Date'], how='left')
    df_for_dwh = df_for_dwh[['DateKey', 'Distribution', 'CountryISO', 'PredictionValues', 'Holiday', 'VersionTime']]
    # sari.creat_dwh_df(sari_forecast_total, country, prediction_start, prediction_end, holiday_df)

    return df_for_dwh