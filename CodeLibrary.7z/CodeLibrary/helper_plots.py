import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


def sarimax_plot_real_vs_fc(y_real: pd.DataFrame, 
                            forecast_df_total: pd.DataFrame,
                            country: str,
                            start: str,
                            end: str,
                            plot_CI: bool,
                            CI: float
                            ):
    """
    Function that shows the differences between the sarimax prediction and the real values (if for historic dates).
        Including the confidence intervals.
    Args:
        y_real: pd.DataFrame, containing the real values for the period we made a prediction for.
        y_predicted: pd.DataFrame, containing the predicted values for the period we made a prediction for.
        country: str, the country we made the analysis.
        start: str, the start date of the prediction that needs to be plot
        end: str, the end date of the prediction that needs to be plot
        plot_CI: bool, statement whether or not to plot the CI.
        CI: float, the level of the confidence inteverval (e.g. 80/90/95//99)

    Returns:
        importances: dict, containg key-value pairs with the feature name and the importance value.
        statistical_overview: dict, overview of the most important statistical scores.
        
    Exaple:

        .. code-block:: python

            import pandas as pd
            import numpy as np
            from datetime import datetime, timedelta
            import matplotlib.pyplot as plt
            date_today = datetime.now()
            np.random.seed(seed=1111)
            days = pd.date_range(date_today, date_today + timedelta(30), freq='D')

            df_real = pd.DataFrame(np.random.randint(1, high=1000, size=31), columns = ['mean'])
            df_real.index = pd.to_datetime(pd.date_range(date_today, date_today + timedelta(30), freq='D'), format ='%Y%m%d' ).strftime('%Y-%m-%d')
            df_pred = pd.DataFrame(np.random.randint(1, high=3000, size=31), columns = ['mean'])
            df_pred.index = pd.to_datetime(pd.date_range(date_today, date_today + timedelta(30), freq='D'), format ='%Y%m%d' ).strftime('%Y-%m-%d')

            df_pred['country'] = 'NL'
            country = 'NL'
            CI = 95
            start = pd.to_datetime(days[5], format='%Y%m%d').strftime('%Y-%m-%d')
            end = pd.to_datetime(days[25], format='%Y%m%d').strftime('%Y-%m-%d')

            sarimax_plot_real_vs_fc(df_real,
                                    df_pred,
                                    start=start,
                                    end= end,
                                    country=country,
                                    plot_CI=False,
                                    CI=CI)
      """
    c_fc = forecast_df_total.Country.unique()
    if c_fc != country:
        print('Not the same country buddy')
        pass
    else:
        fig = plt.figure()
        fig.set_size_inches(12, 8)
        plt.xticks(rotation=90)
        plt.plot(y_real[start:end].index, y_real[start:end], 'k')
        plt.plot(forecast_df_total[start:].index, forecast_df_total['mean'][start:], 'b--')
        if plot_CI == True:
            x = forecast_df_total[start:].index
            y1 = forecast_df_total[start:].mean_ci_lower
            y2 = forecast_df_total[start:].mean_ci_upper
            plt.fill_between(x, y1, y2, alpha=0.2)
            plt.legend(['real', 'forecasted',f'CI_{int(CI*100)}%'])
        else:
            plt.legend(['real', 'forecasted'])

        plt.title(f'Predictions for {country}')
        plt.ioff()
        plt.show()


def plot_fc_sklearn_regression(df_real: pd.DataFrame,df_pred : pd.DataFrame, country: str):
    """
    Function which plots the output of the sk-learn-regression model.
    Args:
        df_pred: pd.DataFrame, the df with the predictions from the model.
    Returns:
        the plot with x-axis the dates and on y-axis the distribution.
    Exaple:

        .. code-block:: python

        country = 'NL'
        df_pred = pd.DataFrame(np.random.randint(1, high=1000, size=31), columns = ['Distribution'])
        df_pred['mean'] = df_pred['Distribution'] / df_pred['Distribution'].sum
        plot_fc_sklearn_regression(df_pred, country=country)
        
    """
    fig = plt.figure()
    fig.set_size_inches(12, 8)
    plt.xticks(rotation=90)
    plt.grid(visible=True, color='b', alpha=.1)
    plt.plot(df_pred.index, df_pred.prediction_values)
    plt.plot(df_real.index, df_real)
    plt.legend(['prediction', 'real_values'])
    plt.title(f'Joiners distribution forecast for {country}')
    plt.xlabel('Date')
    plt.ylabel('Fraction of joiners per day')
    plt.show()

def plot_feature_importance_sklearn(model, feature_importance: dict, country:str):
    """
    Function that shows the relative feature importance of the sk-learn-regression model.
    Args:
        model: the best trained model from the sk-learn regression
        feature_importance: dict, the feature importances of the model.
    Returns:
        plot containing the relative feature importances.
    """
    plt.figure(figsize=(12, 6))
    feature_importance2 = model.feature_importances_
    feature_names = list(feature_importance.keys())
    sorted_idx = np.argsort(feature_importance2)
    pos = np.arange(sorted_idx.shape[0]) + 0.5
    plt.subplot(1, 2, 1)
    plt.barh(pos, feature_importance2[sorted_idx], align="center")
    plt.yticks(pos, np.array(feature_names)[sorted_idx])
    plt.xlabel("Relative importance")
    plt.ylabel("Feature")
    plt.show()
