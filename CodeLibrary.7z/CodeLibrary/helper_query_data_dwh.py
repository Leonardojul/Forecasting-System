"""
IMPORT PYTHON LIBRARIES/MODULES
"""
import pandas as pd
import pyodbc
import numpy as np
import time
from azure.identity import DefaultAzureCredential, AzureCliCredential
from azure.keyvault.secrets import SecretClient

def get_connection_properties(environment: str):
    """
    Function that acquires the necessary connection properties to access a Datawarehouse.

    Args:
         environment (str): The environment toggle which indicates if a connection needs to be 
         made with the DEV database or the PRD database

    Returns:
        user (str): The user used to access the database
        pwd (str): The password used to access the database
        server (str): The server on which the database to be accessed resides
        db (str): The name of the database to be accessed

        """
    print(f"Determining the right connection properties for '{environment}'")

    # Retrieve credentials from Azure Keyvault
    credential = AzureCliCredential()
    # credential = AzureCliCredential()  #Use this one if your local access token has been expired.
    if environment == "DEV":
        vault_url = "https://bf-datascience-dev-kv01.vault.azure.net"
    elif environment == "PRD":
        vault_url = "https://bf-datascience-prd-kv01.vault.azure.net/"
    elif environment == "Datalake-PRD":
        vault_url = "https://bf-datascience-prd-kv01.vault.azure.net/"
    elif environment == "Datalake-DEV":
        vault_url = "https://bf-datascience-dev-kv01.vault.azure.net"
    elif environment == "Canine":
        vault_url = "https://bf-canine-dev-kv01.vault.azure.net/"

    client = SecretClient(
        vault_url=vault_url,
        credential=credential
    )

    if environment == "DEV":
        user = client.get_secret("BF-DataScience-SQL01--User").value
        pwd = client.get_secret("BF-DataScience-SQL01--Password").value
        server = client.get_secret("BF-DataScience-SQL01--DBServer").value
        db = client.get_secret("BF-DataScience-SQL01--DB").value
    elif environment == "PRD":
        user = client.get_secret("BF-DataScience-PRD-SQL01--User").value
        pwd = client.get_secret("BF-DataScience-PRD-SQL01--Password").value
        server = client.get_secret("BF-DataScience-PRD-SQL01--DBServer").value
        db = client.get_secret("BF-DataScience-PRD-SQL01--DB").value
    elif environment == "Datalake-PRD":
        user = client.get_secret("BF-DataPlatform-PRD-SQL01--Username").value
        pwd = client.get_secret("BF-DataPlatform-PRD-SQL01--Password").value
        server = client.get_secret("BF-DataPlatform-PRD-SQL01--DBServer").value
        db = client.get_secret("BF-DataPlatform-PRD-SQL01--DB").value
    elif environment == "Datalake-DEV":
        user = client.get_secret("BF-DataPlatform-DEV-SQL01--Username").value
        pwd = client.get_secret("BF-DataPlatform-DEV-SQL01--Password").value
        server = client.get_secret("BF-DataPlatform-DEV-SQL01--DBServer").value
        db = client.get_secret("BF-DataPlatform-DEV-SQL01--DB").value
    elif environment == "Canine":
        user = client.get_secret("bf-canine-dev-sql01--User").value
        pwd = client.get_secret("bf-canine-dev-sql01--Password").value
        server = client.get_secret("bf-canine-dev-sql01--DBServer").value
        db = client.get_secret("bf-canine-dev-sql01--DB").value
    driver = 'ODBC Driver 17 for SQL Server'

    print(f"Succesfully retrieved the connection properties for '{environment}'!")

    return user, pwd, server, db, driver

def get_data(environment: str,
             query: str,
             query_criteria: str,
             ):
    """
    Queries a Datawarehouse and outputs the table as a dataframe.

    Args:
        environment (str): The environment toggle which indicates if a connection needs to be made with the 
        DEV database or the PRD database
        query (str): The actual query we want to use for querying the data
        query_criteria (str): The optional WHERE statement to be used after the selection on a view.
        Standard is WHERE 1 = 1 in case no WHERE statement is needed

    Returns:
        df (pd.DataFrame): Dataframe with the data output from the query
    """

    #TODO
    # For CS we need to include the list of the channels that can be queried.
    # Add opportunity for substring (e.g. substring = '') then replace if a substring is given in the YAML file.

    print(f"Start Querying Data from DWH for '{query}'")

    user, pwd, server, db, driver = get_connection_properties(environment)

    db_conn = pyodbc.connect(f'DRIVER={driver};SERVER={server};DATABASE={db};UID={user};PWD={pwd}')
    cursor = db_conn.cursor()

    if query_criteria == "":
        query = query
    else:
        query = query + " " + query_criteria

    # Time the moment the read SQL query starts
    start_timer = time.time()

    # Fetch data to DF.
    df = pd.read_sql(query, db_conn)  # without parameters [non-prepared statement]

    # Show how much time the read SQL query took
    print(f'The read SQL query took {time.time() - start_timer} seconds')

    cursor.close()
    db_conn.close()
    print(f'Succesfully queried data from DWH {server}!')

    return df

def post_data_table(environment: str,
                    table_name_dwh: str,
                    col_names: str,
                    df: pd.DataFrame,
                    current_time: str):
    """
    Inserts data into a SQL-server table. Be aware that you first need to create the table in SQL server.
        including the column names and types. The column order in the database and the dataframe also needs
        to be aligned.

    Args:
        environment (str): The environment toggle which indicates if a connection needs to be made with the DEV
        database or the PRD database
        table_name_dwh (str): The table name (with its schema name) where the data should be stored.
        col_names (str): The column names for the table. Only used for the length of columns. Currently we don't define them.
        df (pd.DataFrame): Dataframe to be inserted in the SQL server table
        current_time (str): The time given by the main script which indicates when the result is written to the table

    Returns:
        msg (str): Terminal output confirming that the data is inserted succesfully.

    """

    user, pwd, server, db, driver = get_connection_properties(environment)

    db_conn = pyodbc.connect(f'DRIVER={driver};SERVER={server};DATABASE={db};UID={user};PWD={pwd}')
    cursor = db_conn.cursor()

    table_name_dwh = table_name_dwh

    df['VersionTime'] = current_time
    len_cols = len(col_names)+1

    # Generate the amount of question marks used to insert the values into the table in the later generated write SQL query
    question_marks = str("?," * len_cols)[:-1] # Remove last comma after last question mark

    # Time the moment the write SQL query starts
    start_timer = time.time()

    cursor.execute(f"""
                   SELECT COUNT(*)
                   FROM sys.objects
                   WHERE object_id = OBJECT_ID(N'{table_name_dwh}')
                   AND type in (N'U')
                   """)

    table_exists = cursor.fetchone()[0]

    if table_exists == 1:
        for index, row in df.iterrows():
            cursor.execute(f"INSERT INTO {table_name_dwh} values({question_marks})",
                           [row[x] for x in np.arange(len_cols)])
    else:
        print(f"The table {table_name_dwh} to write data to does not exist, please create the table first on {server}")

    # Show how much time the write SQL query took
    print(f'The write SQL query took {time.time() - start_timer} seconds')

    db_conn.commit()
    cursor.close()

    return f"Data inserted into SQL-Server {server} in case table exists. Otherwise create table in case message was given of table not existing"