import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.ensemble import GradientBoostingRegressor


def split_data(df: pd.DataFrame,
               target: str,
               tr_start: str,
               tr_end: str,
               test_size_dataset: float,
               random_state: int):
    """
    This function splits the data based on the train/test split given. Using the SK-learn split data function.
    Args:
        df: pd.DataFrame, an enriched dataframe for a specific country.
        target: str, the target column
        tr_start:
        tr_end:
        test_size_dataset: float, the value of the training set in decimals (mostly between .05 and .5 )
        random_state: int, the random state, so that we can reproduce values.
    Returns:
        X_train: pd.DataFrame, containing all the feature for the training set.
        X_test: pd.DataFrame, containing all the feature for the test set.
        y_train: pd.DataFrame, containing all real outcomes for the training set.
        y_test: pd.DataFrame, containing all real outcomes for the test set.
    Exaple:

        .. code-block:: python

        import pandas as pd
        import numpy as np
        from sklearn.model_selection import train_test_split
        from datetime import datetime
        test = pd.DataFrame(list(np.arange(60)))
        test = pd.DataFrame(test.values.reshape(30,2), columns = ['col1', 'col2'])
        today = datetime.now().strftime("%Y/%m/%d")
        test.index = pd.date_range(start=today, periods=30, freq='D') + pd.Timedelta(days=1)
        tr_start = test.index[5]
        tr_end =  test.index[20]
        X_train, X_test, y_train, y_test = split_data(test, target = 'col1', tr_start = tr_start,
        tr_end = tr_end, test_size_dataset = 0.1)
    """
    data = df.copy()
    data_new = data[tr_start:tr_end]

    X = data_new.drop(f'{target}', axis=1)
    y = data_new[f'{target}']
    size_training = 1-test_size_dataset
    random_state = random_state
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_size_dataset,
                                                        train_size= size_training,
                                                        random_state=random_state)
    return X_train, X_test, y_train, y_test

def training_v2(X_train: pd.DataFrame,
                 y_train: pd.DataFrame,
                 hyper_space: dict,
                 random_state: int,
                 loss : str,
                 alpha : float
                 ):
    """
    Args:
        X_train: pd.DataFrame, containing all the feature for the training set.
        y_train: pd.DataFrame, containing all the outcomes for the training set.
        hyper_space: dict, containing the values for learning_rate, estimators and depth of RF. Defined in YAML file.
        tr_start: string, the string with the cut-off date that the training set should start.
        tr_end: string, the string with the cut-off date that the training set should send.
    Returns:
         param: dictionary, the best parameters based on the trainingset.
                Parameter setting that gave the best results on the hold out data.
                For multi-metric evaluation, this is not available if refit is False.
                See refit parameter for more information.
         est: float, amount of estimators from the hyper_space (Estimator that was chosen by the search,
             i.e. estimator which gave highest score (or smallest loss if specified) on the left out data.
             Not available if refit=False.
         l_rate: float, the best learning rate for the dataset.
         max_d: int, amount of layers in the Randomized Search
         clf: model the best model based on the GradientBoostingRegressor.
    Example:
        param, est, l_rate, max_d, model = training_new(X_train, y_train, tr_start, tr_end)
    """
    if alpha == 0.5:
        loss = 'squared_error'
    else:
        loss = 'quantile'
    # Set up hyperparameters for testing
    # hyperparameters values to consider for training
    hyper_space = hyper_space
    # the amount of combinations
    value = 1
    for i in hyper_space:
        length = len(hyper_space[i])
        value = value * length
        iteration = value
    iteration = iteration

    clf = GradientBoostingRegressor()

    search = RandomizedSearchCV(clf, hyper_space, scoring='r2', cv=5, verbose=1, n_jobs=-1, n_iter=iteration, random_state=random_state)
    # Documentation on:
    # https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.RandomizedSearchCV.html
    print(f'Features for training: {list(X_train.columns)} ')
    search_results = search.fit(X_train, y_train)
    param = search_results.best_params_

    clf = GradientBoostingRegressor(max_depth=param['max_depth'],
                                    n_estimators=param['n_estimators'],
                                    learning_rate=param['learning_rate'],
                                    random_state=random_state,
                                    loss=loss,
                                    alpha=alpha
                                    ).fit(X_train, y_train)

    return param, param['n_estimators'], param['learning_rate'], param['max_depth'], clf


def training_new(X_train: pd.DataFrame,
                 y_train: pd.DataFrame,
                 hyper_space: dict,
                 random_state: int,
                 ):
    """
    Args:
        X_train: pd.DataFrame, containing all the feature for the training set.
        y_train: pd.DataFrame, containing all the outcomes for the training set.
        hyper_space: dict, containing the values for learning_rate, estimators and depth of RF. Defined in YAML file.
        tr_start: string, the string with the cut-off date that the training set should start.
        tr_end: string, the string with the cut-off date that the training set should send.
    Returns:
         param: dictionary, the best parameters based on the trainingset.
                Parameter setting that gave the best results on the hold out data.
                For multi-metric evaluation, this is not available if refit is False.
                See refit parameter for more information.
         est: float, amount of estimators from the hyper_space (Estimator that was chosen by the search,
             i.e. estimator which gave highest score (or smallest loss if specified) on the left out data.
             Not available if refit=False.
         l_rate: float, the best learning rate for the dataset.
         max_d: int, amount of layers in the Randomized Search
         clf: model the best model based on the GradientBoostingRegressor.
    Exaple:

        .. code-block:: python

        param, est, l_rate, max_d, model = training_new(X_train, y_train, tr_start, tr_end)
    """

    # Set up hyperparameters for testing
    # hyperparameters values to consider for training
    hyper_space = hyper_space
    # the amount of combinations
    value = 1
    for i in hyper_space:
        length = len(hyper_space[i])
        value = value * length
        iteration = value
    iteration = iteration

    clf = GradientBoostingRegressor()

    search = RandomizedSearchCV(clf, hyper_space, scoring='r2', cv=5, verbose=1, n_jobs=-1, n_iter=iteration, random_state=random_state)
    # Documentation on:
    # https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.RandomizedSearchCV.html
    print(f'Features for training: {list(X_train.columns)} ')
    search_results = search.fit(X_train, y_train)
    param = search_results.best_params_

    clf = GradientBoostingRegressor(max_depth=param['max_depth'],
                                    n_estimators=param['n_estimators'],
                                    learning_rate=param['learning_rate'],
                                    random_state= random_state).fit(X_train, y_train)

    return param, param['n_estimators'], param['learning_rate'], param['max_depth'], clf


def test(clf, X_test, y_validation):
    """
    Args:
        X_test: pd.DataFrame, containing all the feature for the test set.
        y_validation: pd.DataFrame, containing all the outcomes for the test set.
        clf: the best model based on the GradientBoostingRegressor from the training set(!)
    Returns:
        score: float, the r2_score for the test set compared to the real data.
        NRMSE: float, the normalized Root Mean Squared Error
        predictions_testset: pd.DataFrame, the predictions (in real numbers) for the testdata,
                based on the best training regressor.
        feature_importance: list, the importance of the features per feature (in column-order)
    Exaple:

        .. code-block:: python

        score, NRMSE, predictions_validation, feature_importance = test(model, X_test, y_test)
    """

    # Using exogenous features.
    y_predicted = clf.predict(X_test)

    # store feature importace
    feature_importance = list(clf.feature_importances_)
    features = X_test.columns
    importances = dict(zip(features, feature_importance))

    # Store the R2, MSE and NRMSE score comparing the validation and the predicted values.
    score = r2_score(y_validation, y_predicted)
    MSE = mean_squared_error(y_validation, y_predicted)
    NRMSE = MSE / (y_validation.max() - y_validation.min())

    return score, NRMSE, y_predicted, importances


def predict_values(df, pred_start, pred_end, country, DatePlaceholder, model, target_col):
    """
    Args:
        target: pd.DataFrame, containing all the data for the respective country.
        pred_start: string, the string with the cut-off date that the prediction set should start.
        pred_end: string, the string with the cut-off date that the prediction set should end.
        country: the country that we make the predictions for (used for filtering)
        DatePlaceholder: the dates we need to make the predictions for.
        model: the best model based on the GradientBoostingRegressor from the training set(!)
    Returns:
         df_pred_norm: pd.DataFrame, the predictions (in % of total per month) for the upcoming month
                    (fixed at the moment) based on the best regressor.
    Exaple:

        .. code-block:: python

            df_pred = hr.predict_values(df_for_model, start_prediction, end_prediction, country, DatePlaceholder,
             model, target_col=target_col)
    """
    randomState = 42
    pred = df[pred_start:pred_end].copy()
    pred = pred.drop(target_col, axis=1)
    predictions = model.predict(pred)
    # to avoid negative numbers due to closures
    print(f'predictions for {country} : ')
    print([np.round(x, 0) for x in predictions])
    predictions_values = predictions.copy()

    predictions = abs(predictions)

    # to calculate monthly distribution: the weight of each day
    total_pred = predictions.sum()
    predictions = predictions / total_pred
    # to create df with prediction results
    df_pred = pd.DataFrame(index=pred.index, data=predictions)
    df_pred['CountryISO'] = country
    df_pred = pd.merge(DatePlaceholder, df_pred, left_index=True, right_index=True)
    df_pred = df_pred.reset_index()
    df_pred.set_index('Date', inplace=True, drop=True)
    df_pred.rename(columns={0: "Distribution"}, inplace=True)
    df_pred.rename(columns={'CalendarKey': "DateKey"}, inplace=True)
    df_pred['prediction_values'] = predictions_values

    #missing value imputation. Take average of day-month over last X months/years.

    avg_last3 = df[:pred_start].copy()
    avg_last3 = avg_last3[:-90]
    avg_last3_grouped = avg_last3.groupby(avg_last3.index.dayofweek)['Joiners'].mean()

    df_pred['DayOfWeek'] = df_pred.index.dayofweek
    avg_last3_grouped = avg_last3_grouped.to_dict()
    df_pred['DayOfWeek'] = df_pred['DayOfWeek'].map(avg_last3_grouped)
    df_pred['prediction_values'] = df_pred['prediction_values'].mask(df_pred['prediction_values'] < 0, df_pred['DayOfWeek'])
    predictions = df_pred['prediction_values'] / df_pred['prediction_values'].sum()
    df_pred['Distribution'] = predictions
    df_pred = df_pred.drop(columns=['DayOfWeek'])

    return df_pred

def predict_joiners_maturity_status(model, X_df: pd.DataFrame, start_prediction: str, end_prediction: str, country: str, mat_status: str):
    """

    Args:
        model: the model used
        X_df: pd.DataFrame, X_variables of predicted period
        start_prediction: str, the date that the cutoff will be for the predictions.
        country: str, the ocuntry that we are predicting for.
        mat_status: str:, the maturity status of the clubs.
    Returns:

    """
    X_pred = X_df.copy()

    X_pred = X_pred.loc[start_prediction:end_prediction]
    predictions = model.predict(X_pred)
    df_pred = pd.DataFrame(index=X_pred.index, data=predictions)
    df_pred.columns = ['JoinersMonth']
    df_pred['Country'] = country
    df_pred['MaturityStatus'] = mat_status
    return df_pred

def predict_values_v2(df, pred_start, pred_end, model, DatePlaceholder, target_col, X_train, y_train):
    pred = df[pred_start:pred_end].copy()
    pred = pred.drop(target_col, axis=1)
    df_pred = pd.DataFrame(model.predict(pred))
    df_pred.columns = ['prediction_values']

    alpha = 0.9

    # Lower bound
    model.set_params(loss='quantile', alpha=1 - alpha)
    m_low = model.fit(X_train, y_train)
    df_lower = m_low.predict(pred)

    # Upper bound
    model.set_params(loss='quantile', alpha=alpha)
    m_up = model.fit(X_train, y_train)
    df_upper = m_up.predict(pred)

    # Merge DF's
    df_total = df_pred.copy()
    df_total['mean_ci_lower'] = df_lower
    df_total['mean_ci_upper'] = df_upper

    DateIndex = list(pd.date_range(pred_start, pred_end))
    df_total.index = DateIndex
    df_total['Date'] = df_total.index.copy()

    avg_last3 = df[:pred_start].copy()
    avg_last3 = avg_last3[:-90]
    avg_last3_grouped = avg_last3.groupby(avg_last3.index.dayofweek)['Joiners'].mean()

    df_total['DayOfWeek'] = df_total.Date.dt.weekday
    avg_last3_grouped = avg_last3_grouped.to_dict()
    df_total['DayOfWeek'] = df_total['DayOfWeek'].map(avg_last3_grouped)
    df_total['prediction_values'] = df_total['prediction_values'].mask(df_total['prediction_values'] < 0, df_total['DayOfWeek'])

    predictions = df_total['prediction_values'] / df_total['prediction_values'].sum()
    df_total['Distribution'] = predictions
    df_total = df_total.drop(columns=['DayOfWeek'])

    df_total.rename(columns={"prediction_values": "mean"}, inplace=True)
    df_total["mean_ci_lower"] = np.where(df_total["mean_ci_lower"] < 0, 0, df_total["mean_ci_lower"])
    df_total = pd.merge(DatePlaceholder, df_total, left_index=True, right_index=True)

    return df_total

### OLD FUNCTIONS