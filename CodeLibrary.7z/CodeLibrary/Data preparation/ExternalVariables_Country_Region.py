import pandas as pd
import numpy as np
import holidays
import datetime
import yaml
import sys
from hijri_converter import Hijri, Gregorian
import helper_query_data_dwh as query_dwh

# DETERMINING BASICS FOR POSTING DATE

# Determine environment
with open('../environment.yml') as file:
    settings_yaml = yaml.load(file, Loader=yaml.FullLoader)
environment = settings_yaml.get('environment')
environment_push_data = settings_yaml.get('environment_push_data')

# Determine environment (if passed through commandline)
if len(sys.argv) > 1:
    environment = str(sys.argv[1])
    environment_push_data = str(sys.argv[2])

# indicate at which time frame data gets loaded into the final table
current_time = str(datetime.datetime.now())
current_time = str(current_time)[:25]

# GENERATING INITIAL DATASET

# indicate which time frame needs to be loaded into the external variables (per country & region) table
begin_date = '2015-01-01'
end_date = '2023-12-31'

# calculate the dates between the start and end date indicated before
date_range = pd.DataFrame({'Date':pd.date_range(start=begin_date, end=end_date)})
# convert the generated dates into calendarkeys such that the final dataset becomes joinable to other dimensions and fact tables
date_range['CalendarKey'] = date_range['Date'].astype(str).str[:4] + date_range['Date'].astype(str).str[5:7]+ date_range['Date'].astype(str).str[8:10]

# create list of countries to include in the external variables (per country & region) table
countries = ['DE', 'BE', 'NL', 'FR', 'ES']
# create multiple lists to indicate the regions per country
regions_DE = ['BB', 'BE', 'BW', 'BY', 'BYP', 'HB', 'HE', 'HH', 'MV', 'NI', 'NW', 'RP', 'SH', 'SL', 'SN', 'ST', 'TH']
regions_BE = []
regions_NL = []
regions_FR = ['Métropole', 'Alsace-Moselle', 'Guadeloupe', 'Guyane', 'Martinique', 'Mayotte', 'Nouvelle-Calédonie', 'La Réunion', 'Polynésie Française', 'Saint-Barthélémy', 'Saint-Martin', 'Wallis-et-Futuna']
regions_ES = ['AN', 'AR', 'AS', 'CB', 'CE', 'CL', 'CM', 'CN', 'CT', 'EX', 'GA', 'IB', 'MC', 'MD', 'NC', 'PV', 'RI', 'VC']

# create dataframes per country and its regions
df_DE = pd.DataFrame({'Country': [countries[0]] * len(regions_DE), 'Region': regions_DE })
df_BE = pd.DataFrame({'Country': [countries[1]] , 'Region': [np.nan] })
df_NL = pd.DataFrame({'Country': [countries[2]] , 'Region': [np.nan] })
df_FR = pd.DataFrame({'Country': [countries[3]] * len(regions_FR), 'Region': regions_FR })
df_ES = pd.DataFrame({'Country': [countries[4]] * len(regions_ES), 'Region': regions_ES })

# concat the aforementioned dataframes into one
countries_and_regions = pd.concat([df_DE, df_BE, df_NL, df_FR, df_ES], ignore_index=True)

# now cross joining the timeframe dataframe and the countries and regions dataframe, such that it results in a dataframe with the generated dates per country and region
date_range['key'] = 1
countries_and_regions['key'] = 1
countries_and_regions_with_dates = pd.merge(countries_and_regions, date_range, on='key').drop("key", 1)
countries_and_regions_with_dates['Date'] = pd.DatetimeIndex(countries_and_regions_with_dates['Date'])
countries_and_regions_with_dates['Year'] = pd.DatetimeIndex(countries_and_regions_with_dates['Date']).year
countries_and_regions_with_dates['Month'] = pd.DatetimeIndex(countries_and_regions_with_dates['Date']).month
countries_and_regions_with_dates['Day'] = pd.DatetimeIndex(countries_and_regions_with_dates['Date']).day

# ADDING NATIONAL AND REGIONAL HOLIDAYS

# with lambda we can execute the country_holidays command to generate potential holidays that occur on a data within a whole country
"""LOOP"""
#CR_NH CR NH
# cr_nh.loc[cr_nh['country']]
for c in countries:
    cr_nh = countries_and_regions_with_dates.copy()
    cr_nh.loc[cr_nh['Country'] == c,'National_holiday'] = cr_nh.loc[cr_nh['Country'] == c,'National_holiday']['Date'].apply(lambda x: holidays.country_holidays(c).get(x)).values
countries_and_regions_with_national_holidays = countries_and_regions_with_dates.copy()
countries_and_regions_with_national_holidays.loc[countries_and_regions_with_national_holidays['Country'] == 'DE', 'National_holiday'] = countries_and_regions_with_national_holidays.loc[countries_and_regions_with_national_holidays['Country'] == 'DE']['Date'].apply(lambda x: holidays.country_holidays('DE').get(x)).values
countries_and_regions_with_national_holidays.loc[countries_and_regions_with_national_holidays['Country'] == 'BE', 'National_holiday'] = countries_and_regions_with_national_holidays.loc[countries_and_regions_with_national_holidays['Country'] == 'BE']['Date'].apply(lambda x: holidays.country_holidays('BE').get(x)).values
countries_and_regions_with_national_holidays.loc[countries_and_regions_with_national_holidays['Country'] == 'NL', 'National_holiday'] = countries_and_regions_with_national_holidays.loc[countries_and_regions_with_national_holidays['Country'] == 'NL']['Date'].apply(lambda x: holidays.country_holidays('NL').get(x)).values
countries_and_regions_with_national_holidays.loc[countries_and_regions_with_national_holidays['Country'] == 'FR', 'National_holiday'] = countries_and_regions_with_national_holidays.loc[countries_and_regions_with_national_holidays['Country'] == 'FR']['Date'].apply(lambda x: holidays.country_holidays('FR').get(x)).values
countries_and_regions_with_national_holidays.loc[countries_and_regions_with_national_holidays['Country'] == 'ES', 'National_holiday'] = countries_and_regions_with_national_holidays.loc[countries_and_regions_with_national_holidays['Country'] == 'ES']['Date'].apply(lambda x: holidays.country_holidays('ES').get(x)).values

# to properly generate the regional holidays per country, it is mandatory for the holidays library to get such requests per year
# thus the dataframe to be fed into the for each loop will be made on per year basis
countries_and_regions_with_years = countries_and_regions_with_dates[['Country','Region','Year']].copy()

# drop duplicates such that we only have one row per country, region, and year
# also drop rows with nan values, indicating countries without regions (for which of course regional holidays do not then apply)
countries_and_regions_with_years = countries_and_regions_with_years.drop_duplicates().dropna()

# create empty list into which the generated dataframes of regional holidays per year and country will be loaded in
dataframes_list = []
# start loop per country, region, and year
for index,row in countries_and_regions_with_years.iterrows():
    # getting the regional holidays
    holidays_dictionary = holidays.country_holidays(row['Country'], subdiv = row['Region'], years= row['Year'])
    # creating dataframe in loop
    temp_df1 = pd.DataFrame(columns=['Country','Region','Year'])
    temp_df2 = pd.DataFrame(data=holidays_dictionary.items())
    temp_df = pd.concat([temp_df1,temp_df2],ignore_index=True) #"""Missing Axis?"""
    temp_df['Country'] = temp_df['Country'].fillna(row['Country'])
    temp_df['Region'] = temp_df['Region'].fillna(row['Region'])
    temp_df['Year'] = temp_df['Year'].fillna(row['Year'])
    # add generated dataframe into list
    dataframes_list.append(temp_df)

# after the loop, concatenate all generated dataframes in the loop into one
countries_and_regions_with_regional_holidays = pd.concat(dataframes_list, ignore_index=True)
countries_and_regions_with_regional_holidays.rename(columns = {0:'Date', 1: 'Regional_holiday'}, inplace = True)
countries_and_regions_with_regional_holidays['Date'] = pd.DatetimeIndex(countries_and_regions_with_regional_holidays['Date'])


# merge the national holiday dataframe with the regional holiday dataframe
"""UNREADABLE; suggest CR = CountryRegion, C= Country, R = Region. NH = NationalHoliday, RH = Regional Holiday"""
countries_and_regions_with_all_holidays = pd.merge(countries_and_regions_with_national_holidays,countries_and_regions_with_regional_holidays[['Country','Region','Date','Regional_holiday']],on =['Country','Region','Date'], how = 'left')
countries_and_regions_with_all_holidays['Regional_holiday']=countries_and_regions_with_all_holidays['Regional_holiday'].replace(np.nan, None)

"""try avoiding double astypes""" #.replace("True": 1
# for science statistics purposes, turn national and regional holidays into numeric variables
countries_and_regions_with_all_holidays['National_holiday'] = countries_and_regions_with_all_holidays['National_holiday'].astype('bool').astype('int')
countries_and_regions_with_all_holidays['Regional_holiday'] = countries_and_regions_with_all_holidays['Regional_holiday'].astype('bool').astype('int')

# ADDING RAMADAN BASED ON HIJRI CALENDAR

countries_and_regions_with_hijri_dates = countries_and_regions_with_dates.copy()
# per country, region, and date add the appropriate Hijri date and month in separate columns
for index, row in countries_and_regions_with_hijri_dates.iterrows():
    date = Gregorian(row['Year'], row['Month'], row['Day']).to_hijri()
    countries_and_regions_with_hijri_dates.at[index,'Hijri_Date'] = date
    countries_and_regions_with_hijri_dates.at[index, 'Hijri_Month'] = date.month

# when it is the 9th month of the Hijri calendar, it is Ramadan.
# it is known that the used python library for the Hijri calendar may not be applicable for all the variants of the Hijri calendar.
# thus take this as a rough estimation of Ramadan.
"""Missing Business Requirements for outer loops"""
countries_and_regions_with_hijri_dates.loc[countries_and_regions_with_hijri_dates['Hijri_Month'] == 9, 'Ramadan'] = 1
countries_and_regions_with_hijri_dates['Ramadan'].fillna(0, inplace = True)

# ADDING WORLD CUP MATCHES
"""DICT from Items would be useful here. Also missing 2022 all values"""
data = [
        # 2018
        ['DE','2018-06-17']
       ,['DE','2018-06-23']
       ,['DE','2018-06-27']
       ,['BE','2018-06-18']
       ,['BE','2018-06-23']
       ,['BE','2018-06-28']
       ,['BE','2018-07-02']
       ,['BE','2018-07-06']
       ,['BE','2018-07-10']
       ,['BE','2018-07-14']
       ,['ES','2018-06-15']
       ,['ES','2018-06-20']
       ,['ES','2018-06-25']
       ,['ES','2018-07-01']
       ,['FR','2018-06-16']
       ,['FR','2018-06-21']
       ,['FR','2018-06-30']
       ,['FR','2018-07-06']
       ,['FR','2018-07-10']
       ,['FR','2018-07-15']
        # 2022
       ,['NL','2022-11-21']
       ,['NL','2022-11-25']
       ,['NL','2022-11-29']
       ,['NL','2022-12-03']
       ,['BE','2022-11-23']
       ,['BE','2022-11-27']
       ,['BE','2022-12-01']
       ,['BE','2022-12-06']
       ,['FR','2022-11-22']
       ,['FR','2022-11-26']
       ,['FR','2022-11-30']
       ,['FR','2022-12-04']
       ,['ES','2022-11-23']
       ,['ES','2022-11-27']
       ,['ES','2022-12-01']
       ,['DE','2022-11-23']
       ,['DE','2022-11-27']
       ,['DE','2022-12-01']
       ]
world_cup_data = pd.DataFrame(data, columns=['Country', 'Date'])
world_cup_data['Date'] = pd.to_datetime(world_cup_data['Date'])
world_cup_data['WorldCup_Match'] = 1

"""Again long lines"""
# ADDING IT ALL TOGETHER (HOLIDAYS, RAMADAN, AND WORLD CUP MATCHES
external_variables_per_country_and_region = \
    pd.merge(countries_and_regions_with_all_holidays[['Country', 'Region', 'Date','Year',
                                                      'CalendarKey','National_holiday','Regional_holiday']],
             countries_and_regions_with_hijri_dates[['Country', 'Region', 'Date', 'Ramadan']],
             how='left', on=['Country', 'Region', 'Date'])
external_variables_per_country_and_region = pd.merge(external_variables_per_country_and_region, world_cup_data[['Country','Date', 'WorldCup_Match']], how='left', on=['Country','Date'])
external_variables_per_country_and_region['WorldCup_Match'].fillna(0, inplace=True)
external_variables_per_country_and_region['Ramadan'] = external_variables_per_country_and_region['Ramadan'].astype(int)
external_variables_per_country_and_region['WorldCup_Match'] = external_variables_per_country_and_region['WorldCup_Match'].astype(int)

#turn nan values to None so SQL takes it as NULL
external_variables_per_country_and_region = external_variables_per_country_and_region.replace(np.nan, None)

with pd.option_context('display.max_columns', None): print(external_variables_per_country_and_region)
query_dwh.post_data_table(environment=environment_push_data
                         ,table_name_dwh='[ds_generic].[ExternalVariables_Country_Region]'
                         ,col_names=external_variables_per_country_and_region.columns
                         ,df=external_variables_per_country_and_region
                         ,current_time=current_time)
print(external_variables_per_country_and_region)


