import pandas as pd
import numpy as np
import requests
from datetime import date
import datetime
import yaml
import sys
import helper_query_data_dwh as query_dwh

# DETERMINING BASICS FOR POSTING DATE

# Determine environment
with open('../environment.yml') as file:
    settings_yaml = yaml.load(file, Loader=yaml.FullLoader)
environment = settings_yaml.get('environment')
environment_push_data = settings_yaml.get('environment_push_data')

# Determine environment (if passed through commandline)
if len(sys.argv) > 1:
    environment = str(sys.argv[1])
    environment_push_data = str(sys.argv[2])

# indicate at which time frame data gets loaded into the final table
current_time = str(datetime.datetime.now())
current_time = str(current_time)[:25]

# GENERATING INITIAL DATASET
"""DOUBLE"""
# indicate at which time frame data gets loaded into the final table
current_time = str(datetime.datetime.now())
current_time = str(current_time)[:25]

# indicate which time frame needs to be loaded into the external variables (per country & school holiday zone) table
begin_date = '2015-01-01'
end_date = '2023-12-31'

# calculate the dates between the start and end date indicated before
date_range = pd.DataFrame({'Date':pd.date_range(start=begin_date, end=end_date)})
# convert the generated dates into calendarkeys such that the final dataset becomes joinable to other dimensions and fact tables
date_range['CalendarKey']= date_range['Date'].astype(str).str[:4] + date_range['Date'].astype(str).str[5:7]+ date_range['Date'].astype(str).str[8:10]

# create list of countries to include in the external variables (per country & school holiday zone) table
countries = ['DE', 'BE', 'NL', 'FR', 'ES']
# create multiple lists to indicate the school holiday zones per country
school_holiday_zones_DE = ['DE-BB', 'DE-BE', 'DE-BW', 'DE-BY', 'DE-HB', 'DE-HE', 'DE-HH', 'DE-MV', 'DE-NI', 'DE-NW', 'DE-RP', 'DE-SH', 'DE-SL', 'DE-SN', 'DE-ST', 'DE-TH']
school_holiday_zones_NL = ['NL-NO','NL-MI','NL-ZU']
school_holiday_zones_FR = ['FR-ZA','FR-ZB','FR-ZC']
school_holiday_zones_ES = ['AN', 'AR', 'AS', 'CB', 'CE', 'CL', 'CM', 'CN', 'CT', 'EX', 'GA', 'IB', 'MC', 'MD', 'NC', 'PV', 'RI', 'VC']

# create dataframes per country and its school holiday zones
df_DE = pd.DataFrame({'Country': [countries[0]] * len(school_holiday_zones_DE), 'School_holiday_zone': school_holiday_zones_DE})
df_BE = pd.DataFrame({'Country': [countries[1]], 'School_holiday_zone': [np.nan] })
df_NL = pd.DataFrame({'Country': [countries[2]] * len(school_holiday_zones_NL), 'School_holiday_zone': school_holiday_zones_NL})
df_FR = pd.DataFrame({'Country': [countries[3]] * len(school_holiday_zones_FR), 'School_holiday_zone': school_holiday_zones_FR})
df_ES = pd.DataFrame({'Country': [countries[4]] * len(school_holiday_zones_ES), 'School_holiday_zone': school_holiday_zones_ES })

# concat the aforementioned dataframes into one
countries_and_school_zones = pd.concat([df_DE,df_BE,df_NL,df_FR,df_ES],ignore_index=True)

# now cross joining the timeframe dataframe and the countries and school holiday zones dataframe, such that it results in a dataframe with the generated dates per country and school holiday zone
date_range['key'] = 1
countries_and_school_zones['key'] = 1
countries_and_school_zones_with_dates = pd.merge(countries_and_school_zones, date_range, on='key').drop("key", 1)
countries_and_school_zones_with_dates['Date'] = pd.DatetimeIndex(countries_and_school_zones_with_dates['Date'])
countries_and_school_zones_with_dates['Year'] = pd.DatetimeIndex(countries_and_school_zones_with_dates['Date']).year

# ADDING SCHOOL HOLIDAYS
"""Please add references here/URL links where static-data comes from. For other users"""
# to add the school holidays per country and school holiday zone, we use an api as much as we can to automate this process
# unfortunately the api that was available during the time of writing only contains data starting from 2020 for Germany, Netherlands, and France
# for these countries and timeframes the api is used, static datasets are later on used to fill in the gaps (remaining years, and adding Spain +  Belgium.
# the api works per year, thus a dataframe for the relevant timeframe and countries is made to be given to the api
countries_and_school_zones_per_year = countries_and_school_zones_with_dates[['Country','School_holiday_zone','Year']].drop_duplicates().copy()
"""Line too long"""
countries_and_school_zones_per_year = countries_and_school_zones_per_year.loc[(countries_and_school_zones_per_year['Country'] == 'DE')| (countries_and_school_zones_per_year['Country'] == 'NL') | (countries_and_school_zones_per_year['Country'] == 'FR')]
# create empty list into which the generated dataframes of school holidays per country and school holiday zone will be loaded in
dataframes_list = []
# start loop per country, school holiday zone, and year (starting from 2020)
for index, row in countries_and_school_zones_per_year.loc[countries_and_school_zones_per_year['Year'] >= 2020].iterrows():
    # creating the parameters which are needed for the api (based on dataframe values)
    countryisocode = row['Country']
    subdivisioncode = row['School_holiday_zone']
    year_start = date(row['Year'], 1, 1)
    year_end = date(row['Year'], 12, 31)

    # in case the data of Germany is passed to the api, use an api call that uses subdivision iso codes
    if row['Country'] == 'DE':
        api_get_uri = f'https://openholidaysapi.org/SchoolHolidays?countryIsoCode={countryisocode}&subdivisionIsoCode={subdivisioncode}&languageIsoCode=EN&validFrom={year_start}&validTo={year_end}'

    # in case data of Netherlands or France is passed to the api, use an api call that uses oUnitcode
    if row['Country'] == 'NL' or row['Country'] == 'FR':
        api_get_uri = f'https://openholidaysapi.org/SchoolHolidays?countryIsoCode={countryisocode}&oUnitCode={subdivisioncode}&languageIsoCode=EN&validFrom={year_start}&validTo={year_end}'

    # use the generated uri on the call, indicate that the response should be in json format
    r = requests.get(api_get_uri,headers={'accept': 'text/json'})
    r = r.json()
    # flatten the json response into dataframe
    temp_df = pd.json_normalize(r).explode(['subdivisions'])[['id', 'startDate', 'endDate', 'name', 'subdivisions','comment']]
    # retrieve code value within subdivisions
    temp_df = temp_df.assign(code=temp_df['subdivisions'].str['code'])
    # only select from the json response the rows related to the school holiday zone in the loop (normally the api should only provide rows related to the school holiday zone, because we give this value to the request. But the api is broken in this, so we filter again here
    temp_df = temp_df.loc[temp_df['code'] == subdivisioncode]
    # retrieve shortname within subdivisions
    temp_df = temp_df.assign(shortName=temp_df['subdivisions'].str['shortName'])
    # turn the name value into a string and only select a substring of it to remove unneccessary characters around the name
    temp_df['name'] = temp_df['name'].astype(str)
    temp_df['name'] = temp_df['name'].str[29:-3]
    # turn the comment value into a string and only select rows from the json response that have rows without a value in the comment, or where "General Schools" is mentioned in the comment (to exclude duplications due to sub selections of types of schools within one holiday in one school holiday zone
    temp_df['comment'] = temp_df['comment'].astype(str)
    temp_df = temp_df.loc[(temp_df["comment"].str.contains("General Schools")) | (temp_df["comment"] == '[]')]
    temp_df = temp_df.reset_index()


    # create dataframe which contains the country in the loop with its school holidays in the relevant school holiday zone
    countries_and_school_holidays = pd.DataFrame()
    countries_and_school_holidays['Region'] = temp_df['shortName']
    countries_and_school_holidays['School_holiday'] = temp_df['name']
    countries_and_school_holidays['Start_date'] = temp_df['startDate']
    countries_and_school_holidays['End_date'] = temp_df['endDate']
    countries_and_school_holidays['Country'] = row['Country']
    countries_and_school_holidays['School_holiday_zone'] = row['School_holiday_zone']
    # generate the dates between the start and end dates of the school holiday periods and then expand on these generated dates
    countries_and_school_holidays['Date'] = countries_and_school_holidays.apply(lambda x: pd.date_range(start=x['Start_date'], end=x['End_date']), axis=1)
    countries_and_school_holidays = countries_and_school_holidays.explode('Date').reset_index(drop=True)
    # add generated dataframe into list
    dataframes_list.append(countries_and_school_holidays)

# after the loop, concatenate all generated dataframes in the loop into one
countries_and_school_zones_with_school_holidays = pd.concat(dataframes_list, ignore_index=True)

# Christmas Holidays go across muliple school years, to precent duplication due to this per year a drop_duplicates for rows about Christmas Holidays is done
christmas_holidays_indexes = countries_and_school_zones_with_school_holidays.loc[(countries_and_school_zones_with_school_holidays['School_holiday'] == 'Christmas holidays') | (countries_and_school_zones_with_school_holidays['School_holiday'] == 'Christmas Holidays')]
christmas_holidays_indexes_complete = christmas_holidays_indexes.index
christmas_holidays_indexes = christmas_holidays_indexes.drop_duplicates()
christmas_holidays_indexes_without_duplicates= christmas_holidays_indexes.index
christmas_holidays_indexes_duplicates = christmas_holidays_indexes_complete.difference(christmas_holidays_indexes_without_duplicates)
countries_and_school_zones_with_school_holidays.drop(index=christmas_holidays_indexes_duplicates, inplace=True)

# Forced to make a static dataset for Dutch school holidays to fill the gaps which are not generated by the applied api
dutch_NO_school_holidays = [['Christmas break','2014-12-20','2015-01-04'],['Spring break','2015-02-21','2015-03-01'],['May holiday','2015-05-02','2015-05-10'],['Summer holiday','2015-07-04','2015-08-16'],['Autumn break','2015-10-17','2015-10-25'] #2015
                          ,['Christmas break','2015-12-19','2016-01-03'],['Spring break','2016-02-27','2016-03-06'],['May holiday','2016-04-30','2016-05-08'],['Summer holiday','2016-07-16','2016-08-28'],['Autumn break','2016-10-15','2016-10-23'] #2016
                          ,['Christmas break','2016-12-24','2017-01-08'],['Spring break','2017-02-18','2017-02-26'],['May holiday','2017-04-22','2017-04-30'],['Summer holiday','2017-07-22','2017-09-03'],['Autumn break','2017-10-21','2017-10-29'] #2017
                          ,['Christmas break','2017-12-23','2018-01-07'],['Spring break','2018-02-24','2018-03-04'],['May holiday','2018-04-28','2018-05-06'],['Summer holiday','2018-07-21','2018-09-02'],['Autumn break','2018-10-20','2018-10-28'] #2018
                          ,['Christmas break','2018-12-22','2019-01-06'],['Spring break','2019-02-16','2019-02-24'],['May holiday','2019-04-27','2019-05-05'],['Summer holiday','2019-07-13','2019-08-25'],['Autumn break','2019-10-12','2019-10-20'] #2019
                          ]

dutch_NO_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=dutch_NO_school_holidays)
dutch_NO_school_holidays_dataframe['Country'] = 'NL'
dutch_NO_school_holidays_dataframe['School_holiday_zone'] = 'NL-NO'


dutch_MI_school_holidays = [['Christmas break','2014-12-20','2015-01-04'],['Spring break','2015-02-21','2015-03-01'],['May holiday','2015-05-02','2015-05-10'],['Summer holiday','2015-07-11','2015-08-23'],['Autumn break','2015-10-17','2015-10-25'] #2015
                          ,['Christmas break','2015-12-19','2016-01-03'],['Spring break','2016-02-20','2016-02-28'],['May holiday','2016-04-30','2016-05-08'],['Summer holiday','2016-07-09','2016-08-21'],['Autumn break','2016-10-15','2016-10-23'] #2016
                          ,['Christmas break','2016-12-24','2017-01-08'],['Spring break','2017-02-25','2017-03-05'],['May holiday','2017-04-22','2017-04-30'],['Summer holiday','2017-07-08','2017-08-20'],['Autumn break','2017-10-14','2017-10-22'] #2017
                          ,['Christmas break','2017-12-23','2018-01-07'],['Spring break','2018-02-24','2018-03-04'],['May holiday','2018-04-28','2018-05-06'],['Summer holiday','2018-07-14','2018-08-26'],['Autumn break','2018-10-20','2018-10-28'] #2018
                          ,['Christmas break','2018-12-22','2019-01-06'],['Spring break','2019-02-23','2019-03-03'],['May holiday','2019-04-27','2019-05-05'],['Summer holiday','2019-07-20','2019-09-01'],['Autumn break','2019-10-12','2019-10-20'] #2019
                          ]

dutch_MI_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=dutch_MI_school_holidays)
dutch_MI_school_holidays_dataframe['Country'] = 'NL'
dutch_MI_school_holidays_dataframe['School_holiday_zone'] = 'NL-MI'

dutch_ZU_school_holidays = [['Christmas break','2014-12-20','2015-01-04'],['Spring break','2015-02-14','2015-02-22'],['May holiday','2015-05-02','2015-05-10'],['Summer holiday','2015-07-18','2015-08-30'],['Autumn break','2015-10-24','2015-11-01'] #2015
                          ,['Christmas break','2015-12-19','2016-01-03'],['Spring break','2016-02-20','2016-02-28'],['May holiday','2016-04-30','2016-05-08'],['Summer holiday','2016-07-23','2016-09-04'],['Autumn break','2016-10-22','2016-10-30'] #2016
                          ,['Christmas break','2016-12-24','2017-01-08'],['Spring break','2017-02-25','2017-03-05'],['May holiday','2017-04-22','2017-04-30'],['Summer holiday','2017-07-15','2017-08-27'],['Autumn break','2017-10-14','2017-10-22'] #2017
                          ,['Christmas break','2017-12-23','2018-01-07'],['Spring break','2018-02-17','2018-02-25'],['May holiday','2018-04-28','2018-05-06'],['Summer holiday','2018-07-07','2018-08-19'],['Autumn break','2018-10-13','2018-10-21'] #2018
                          ,['Christmas break','2018-12-22','2019-01-06'],['Spring break','2019-02-23','2019-03-03'],['May holiday','2019-04-27','2019-05-05'],['Summer holiday','2019-07-06','2019-08-18'],['Autumn break','2019-10-19','27-10-2019'] #2019
                          ]

dutch_ZU_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=dutch_ZU_school_holidays)
dutch_ZU_school_holidays_dataframe['Country'] = 'NL'
dutch_ZU_school_holidays_dataframe['School_holiday_zone'] = 'NL-ZU'

dutch_school_holidays_list = [dutch_NO_school_holidays_dataframe
                             ,dutch_MI_school_holidays_dataframe
                             ,dutch_ZU_school_holidays_dataframe
                             ]

# concat the aforementioned dataframes into one
dutch_school_holidays = pd.concat(dutch_school_holidays_list, ignore_index=True)

# generate the dates between the start and end dates of the school holiday periods and then expand on these generated dates
dutch_school_holidays['Date'] = dutch_school_holidays.apply(lambda x: pd.date_range(start=x['Start_date'], end=x['End_date']), axis=1)
dutch_school_holidays = dutch_school_holidays.explode('Date').reset_index(drop=True)

# Forced to make a static dataset for French school holidays to fill the gaps which are not generated by the applied api
french_ZA_school_holidays = [['Christmas break','2014-12-20','2015-01-05'],['Winter holiday','2015-02-07','2015-02-23'],['Spring holiday','2015-04-11','2015-04-27'],['Summer holiday','2015-07-04','2015-08-31'],['Autumn break','2015-10-18','2015-11-01'] #2015
                          , ['Christmas break','2015-12-20','2016-01-03'],['Winter holiday','2016-02-14','2016-02-28'],['Spring holiday','2016-04-10','2016-04-24'],['Summer holiday','2016-07-06','2016-08-31'],['Autumn break','2016-10-20','2016-11-01'] #2016
                          , ['Christmas break','2016-12-18','2017-01-02'],['Winter holiday','2017-02-19','2017-03-05'],['Spring holiday','2017-04-16','2017-05-01'],['Summer holiday','2017-07-09','2017-09-03'],['Autumn break','2017-10-22','2017-11-05'] #2017
                          , ['Christmas break','2017-12-24','2018-01-07'],['Winter holiday','2018-02-11','2018-02-25'],['Spring holiday','2018-04-08','2018-04-22'],['Summer holiday','2018-07-08','2018-09-01'],['Autumn break','2018-10-21','2018-11-04'] #2018
                          , ['Christmas break','2018-12-23','2019-01-06'],['Winter holiday','2019-02-17','2019-03-03'],['Spring holiday','2019-04-14','2019-04-28'],['Summer holiday','2019-07-07','2019-09-01'],['Autumn break','2019-10-20','2019-11-03']#2019
                          ]

french_ZA_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=french_ZA_school_holidays)
french_ZA_school_holidays_dataframe['Country'] = 'FR'
french_ZA_school_holidays_dataframe['School_holiday_zone'] = 'FR-ZA'

french_ZB_school_holidays = [['Christmas break','2014-12-20','2015-01-05'],['Winter holiday','2015-02-21','2015-03-09'],['Spring holiday','2015-04-25','2015-05-11'],['Summer holiday','2015-07-04','2015-08-31'],['Autumn break','2015-10-18','2015-11-01'] #2015
                          , ['Christmas break','2015-12-20','2016-01-03'],['Winter holiday','2016-02-07','2016-02-21'],['Spring holiday','2016-04-03','2016-04-17'],['Summer holiday','2016-07-06','2016-08-31'],['Autumn break','2016-10-20','2016-11-01'] #2016
                          , ['Christmas break','2016-12-18','2017-01-02'],['Winter holiday','2017-02-12','2017-02-26'],['Spring holiday','2017-04-09','2017-04-23'],['Summer holiday','2017-07-09','2017-09-03'],['Autumn break','2017-10-22','2017-11-05'] #2017
                          , ['Christmas break','2017-12-24','2018-01-07'],['Winter holiday','2018-02-25','2018-03-11'],['Spring holiday','2018-04-22','2018-05-06'],['Summer holiday','2018-07-08','2018-09-01'],['Autumn break','2018-10-21','2018-11-04'] #2018
                          , ['Christmas break','2018-12-23','2019-01-06'],['Winter holiday','2019-02-10','2019-02-24'],['Spring holiday','2019-04-07','2019-04-22'],['Summer holiday','2019-07-07','2019-09-01'],['Autumn break','2019-10-20','2019-11-03'] #2019
                          ]

french_ZB_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=french_ZB_school_holidays)
french_ZB_school_holidays_dataframe['Country'] = 'FR'
french_ZB_school_holidays_dataframe['School_holiday_zone'] = 'FR-ZB'

french_ZC_school_holidays = [['Christmas break','2014-12-20','2015-01-05'],['Winter holiday','2015-02-14','2015-03-02'],['Spring holiday','2015-04-18','2015-05-04'],['Summer holiday','2015-07-04','2015-08-31'],['Autumn break','2015-10-18','2015-11-01'] #2015
                          , ['Christmas break','2015-12-20','2016-01-03'],['Winter holiday','2016-02-21','2016-03-06'],['Spring holiday','2016-04-17','2016-05-01'],['Summer holiday','2016-07-06','2016-08-31'],['Autumn break','2016-10-20','2016-11-01'] #2016
                          , ['Christmas break','2016-12-18','2017-01-02'],['Winter holiday','2017-02-05','2017-02-19'],['Spring holiday','2017-04-02','2017-04-17'],['Summer holiday','2017-07-09','2017-09-03'],['Autumn break','2017-10-22','2017-11-05'] #2017
                          , ['Christmas break','2017-12-24','2018-01-07'],['Winter holiday','2018-02-18','2018-03-04'],['Spring holiday','2018-04-15','2018-04-29'],['Summer holiday','2018-07-08','2018-09-01'],['Autumn break','2018-10-21','2018-11-04'] #2018
                          , ['Christmas break','2018-12-23','2019-01-06'],['Winter holiday','2019-02-24','2019-03-10'],['Spring holiday','2019-04-21','2019-05-05'],['Summer holiday','2019-07-07','2019-09-01'],['Autumn break','2019-10-20','2019-11-03'] #2019
                          ]

french_ZC_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=french_ZB_school_holidays)
french_ZC_school_holidays_dataframe['Country'] = 'FR'
french_ZC_school_holidays_dataframe['School_holiday_zone'] = 'FR-ZC'

french_school_holidays_list = [french_ZA_school_holidays_dataframe
                             ,french_ZB_school_holidays_dataframe
                             ,french_ZC_school_holidays_dataframe
                             ]

# concat the aforementioned dataframes into one
french_school_holidays = pd.concat(french_school_holidays_list, ignore_index=True)

# generate the dates between the start and end dates of the school holiday periods and then expand on these generated dates
french_school_holidays['Date'] = french_school_holidays.apply(lambda x: pd.date_range(start=x['Start_date'], end=x['End_date']), axis=1)
french_school_holidays = french_school_holidays.explode('Date').reset_index(drop=True)

# Forced to make a static dataset for German school holidays to fill the gaps which are not generated by the applied api
german_BB_school_holidays = [['Christmas break','2014-12-22','2015-01-02'],['Winter holiday','2015-02-02','2015-02-07'],['Easter holiday','2015-04-01','2015-04-11'],['Pentecost','2015-05-15','2015-05-15'],['Summer holiday','2015-07-16','2015-08-28'],['Autumn break','2015-10-19','2015-10-30'] #2015
                          , ['Christmas break','2015-12-23','2016-01-02'],['Winter holiday','2016-02-01','2016-02-06'],['Easter holiday','2016-03-23','2016-04-02'],['Pentecost','2016-05-17','2016-05-17'],['Summer holiday','2016-07-21','2016-09-03'],['Autumn break','2016-10-17','2016-10-28'] #2016
                          , ['Christmas break','2016-12-23','2017-01-03'],['Winter holiday','2017-01-30','2017-02-04'],['Easter holiday','2017-04-12','2017-04-22'],['Summer holiday','2017-07-20','2017-09-01'],['Autumn break','2017-10-23','2017-11-04'] #2017
                          , ['Christmas break','2017-12-21','2018-01-02'],['Winter holiday','05-02-2018','2018-02-10'],['Easter holiday','2018-03-26','2018-04-06'],['Pentecost','2018-04-30','2018-04-30'],['Summer holiday','2018-07-05','2018-08-18'],['Autumn break','2018-10-22','2018-11-02'] #2018
                          , ['Christmas break','2018-12-21','2019-01-05'],['Winter holiday','2019-02-04','2019-02-09'],['Easter holiday','2019-04-15','2019-04-26'],['Summer holiday','2019-06-20','2019-08-03'],['Autumn break','2019-10-04','2019-10-18'] #2019
                          ]

german_BB_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_BB_school_holidays)
german_BB_school_holidays_dataframe['Country'] = 'DE'
german_BB_school_holidays_dataframe['School_holiday_zone'] = 'DE-BB'

german_BE_school_holidays = [['Christmas break','2014-12-22','2015-01-02'],['Winter holiday','2015-02-02','2015-02-07'],['Easter holiday','2015-03-30','2015-04-11'],['Pentecost','2015-05-15','2015-05-15'],['Pentecost','2015-05-26','2015-05-26'],['Summer holiday','2015-07-16','2015-08-28'],['Autumn break','2015-10-19','2015-10-31'] #2015
                          , ['Christmas break','2015-12-23','2016-01-02'],['Winter holiday','2016-02-01','2016-02-06'],['Easter holiday','2016-03-21','2016-04-02'],['Pentecost','2016-03-06','2016-03-06'],['Pentecost','2016-03-17','2016-03-18'],['Summer holiday','2016-07-21','2016-09-02'],['Autumn break','2016-10-17','2016-10-28'] #2016
                          , ['Christmas break','2016-12-23','2017-01-03'],['Winter holiday','2017-01-30','2017-02-03'],['Easter holiday','2017-04-10','2017-04-18'],['Pentecost','2017-05-24','2017-05-24'],['Pentecost','26-05-2017','26-05-2017'],['Pentecost','2017-06-06','2017-06-09'],['Summer holiday','2017-07-20','2017-09-01'],['Autumn break','2017-10-02','2017-10-02'],['Autumn break','2017-10-23','2017-11-04'] #2017
                          , ['Christmas break','2017-12-21','2018-01-02'],['Winter holiday','2018-02-05','2018-02-10'],['Easter holiday','2018-03-26','2018-04-06'],['Pentecost','2018-04-30','2018-04-30'],['Pentecost','2018-05-11','2018-05-22'],['Summer holiday','2018-07-05','2018-08-17'],['Autumn break','2018-10-22','2018-11-02'] #2018
                          , ['Christmas break','2018-12-22','2019-01-05'],['Winter holiday','2019-02-04','2019-02-09'],['Easter holiday','2019-04-15','2019-04-26'],['Pentecost','2019-05-31','2019-05-31'],['Pentecost','2019-06-11','2019-06-11'],['Summer holiday','2019-06-20','2019-08-02'],['Autumn break','2019-10-04','2019-10-04'],['Autumn break','2019-10-07','2019-10-19'] #2019
                          ]

german_BE_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_BE_school_holidays)
german_BE_school_holidays_dataframe['Country'] = 'DE'
german_BE_school_holidays_dataframe['School_holiday_zone'] = 'DE-BE'

german_BW_school_holidays = [['Christmas break','2014-12-22','2015-01-05'],['Easter holiday','2015-03-30','2015-04-10'],['Pentecost','2015-05-26','2015-06-06'],['Summer holiday','2015-07-30','2015-09-12'],['Autumn break','2015-10-31','2015-10-31'],['Autumn break','2015-11-02','2015-11-06'] #2015
                          , ['Christmas break','2015-12-23','2016-01-09'],['Easter holiday','2016-03-29','2016-04-02'],['Pentecost','2016-05-17','2016-05-28'],['Summer holiday','2016-07-28','2016-09-10'],['Autumn break','2016-11-02','2016-11-04'] #2016
                          , ['Christmas break','2016-12-23','2017-01-07'],['Easter holiday','2017-04-10','2017-04-21'],['Pentecost','2017-06-06','2017-06-16'],['Summer holiday','2017-07-27','2017-09-09'],['Autumn break','2017-10-30','2017-11-03'] #2017
                          , ['Christmas break','2017-12-22','2018-01-05'],['Easter holiday','2018-03-26','2018-04-06'],['Pentecost','2018-05-22','2018-06-02'],['Summer holiday','2018-07-26','2018-09-08'],['Autumn break','2018-10-29','2018-11-02'] #2018
                          , ['Christmas break','2018-12-24','2019-01-05'],['Easter holiday','2019-04-15','2019-04-27'],['Pentecost','2019-06-11','2019-06-12'],['Summer holiday','2019-07-29','2019-09-10'],['Autumn break','2019-10-28','2019-10-31'] #2019
                          ]

german_BW_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_BW_school_holidays)
german_BW_school_holidays_dataframe['Country'] = 'DE'
german_BW_school_holidays_dataframe['School_holiday_zone'] = 'DE-BW'

german_BY_school_holidays = [['Christmas break','2014-12-24','2015-01-05'],['Winter holiday','2015-02-16','2015-02-20'],['Easter holiday','2015-03-30','2015-04-11'],['Pentecost','2015-05-26','2015-06-05'],['Summer holiday','2015-08-01','2015-09-14'],['Autumn break','2015-11-02','2015-11-07'],['Autumn break','2015-11-18','2015-11-18'] #2015
                          , ['Christmas break','2015-12-24','2016-01-05'],['Winter holiday','2016-02-08','2016-02-12'],['Easter holiday','2016-03-21','2016-04-01'],['Pentecost','2016-05-17','2016-05-28'],['Summer holiday','2016-07-30','2016-09-12'],['Autumn break','2016-10-31','2016-11-04'],['Autumn break','2016-11-16','2016-11-16'] #2016
                          , ['Christmas break','2016-12-24','2017-01-05'],['Winter holiday','2017-02-27','2017-03-03'],['Easter holiday','2017-04-10','2017-04-22'],['Pentecost','2017-06-06','2017-06-16'],['Summer holiday','2017-07-29','2017-09-11'],['Autumn break','2017-10-30','2017-10-30'],['Autumn break','2017-11-03','2017-11-22'] #2017
                          , ['Christmas break','2017-12-23','2018-01-05'],['Winter holiday','2018-02-12','2018-02-16'],['Easter holiday','2018-03-26','2018-04-07'],['Pentecost','2018-05-22','2018-06-02'],['Summer holiday','2018-07-30','2018-09-10'],['Autumn break','2018-10-29','2018-11-02'],['Autumn break','2018-11-21','2018-11-21'] #2018
                          , ['Christmas break','2018-12-22','2019-01-05'],['Winter holiday','2019-03-04','2019-03-08'],['Easter holiday','2019-04-15','2019-04-27'],['Pentecost','2019-06-11','2019-06-21'],['Summer holiday','2019-07-29','2019-09-09'],['Autumn break','2019-10-28','2019-10-31'],['Autumn break','2019-11-20','2019-11-20'] #2019
                          ]

german_BY_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_BY_school_holidays)
german_BY_school_holidays_dataframe['Country'] = 'DE'
german_BY_school_holidays_dataframe['School_holiday_zone'] = 'DE-BY'

german_HB_school_holidays = [['Christmas break','2014-12-22','2015-01-05'],['Winter holiday','2015-02-02','2015-02-03'],['Easter holiday','2015-03-25','2015-04-10'],['Pentecost','2015-05-15','2015-05-15'],['Pentecost','2015-05-26','2015-05-26'],['Summer holiday','2015-07-23','2015-09-02'],['Autumn break','2015-10-19','2015-10-31'] #2015
                          , ['Christmas break','2015-12-23','2016-01-06'],['Winter holiday','2016-01-28','2016-01-29'],['Easter holiday','2016-03-18','2016-04-02'],['Pentecost','2016-05-06','2016-05-06'],['Pentecost','2016-05-17','2016-05-17'],['Summer holiday','2016-06-23','2016-08-03'],['Autumn break','2016-10-04','2016-10-15'] #2016
                          , ['Christmas break','2016-12-21','2017-01-06'],['Winter holiday','2017-01-30','2017-01-31'],['Easter holiday','2017-04-10','2017-04-22'],['Pentecost','2017-05-26','2017-05-26'],['Pentecost','2017-06-06','2017-06-06'],['Summer holiday','2017-06-22','2017-08-02'],['Autumn break','2017-10-02','2017-10-14'],['Autumn break','2017-10-30','2017-10-30'] #2017
                          , ['Christmas break','2017-12-23','2018-01-06'],['Winter holiday','2018-02-01','2018-02-02'],['Easter holiday','2018-03-19','2018-04-03'],['Pentecost','2018-04-30','2018-04-30'],['Summer holiday','2018-06-28','2018-08-08'],['Autumn break','2018-10-01','2018-10-13'] #2018
                          , ['Christmas break','2018-12-24','2019-01-04'],['Winter holiday','2019-01-31','2019-02-01'],['Easter holiday','2019-04-06','2019-04-23'],['Pentecost','2019-05-31','2019-05-31'],['Summer holiday','2019-07-04','2019-08-14'],['Autumn break','2019-10-04','2019-10-18'] #2019
                          ]

german_HB_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_HB_school_holidays)
german_HB_school_holidays_dataframe['Country'] = 'DE'
german_HB_school_holidays_dataframe['School_holiday_zone'] = 'DE-HB'

german_HE_school_holidays = [['Christmas break','2014-12-22','2015-01-10'],['Easter holiday','2015-03-30','2015-04-11'],['Summer holiday','2015-07-27','2015-09-04'],['Autumn break','2015-10-19','2015-10-31'] #2015
                          , ['Christmas break','2015-12-23','2016-01-09'],['Easter holiday','2016-03-29','2016-04-09'],['Summer holiday','2016-07-18','2016-08-26'],['Autumn break','2016-10-17','2016-10-29'] #2016
                          , ['Christmas break','2016-12-22','2017-01-07'],['Easter holiday','2017-04-03','2017-04-15'],['Summer holiday','2017-07-03','2017-08-11'],['Autumn break','2017-10-09','2017-10-21'] #2017
                          , ['Christmas break','2017-12-24','2018-01-13'],['Easter holiday','2018-03-26','2018-04-07'],['Summer holiday','2018-06-25','2018-08-03'],['Autumn break','2018-10-01','2018-10-13'] #2018
                          , ['Christmas break','2018-12-24','2019-01-12'],['Easter holiday','2019-04-14','2019-04-27'],['Summer holiday','2019-07-01','2019-08-09'],['Autumn break','2019-09-30','2019-10-12'] #2019
                          ]

german_HE_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_HE_school_holidays)
german_HE_school_holidays_dataframe['Country'] = 'DE'
german_HE_school_holidays_dataframe['School_holiday_zone'] = 'DE-HE'

german_HH_school_holidays = [['Christmas break','2014-12-22','2015-01-06'],['Winter holiday','2015-01-30','2015-01-30'],['Easter holiday','2015-03-02','2015-03-13'],['Pentecost','2015-05-11','2015-05-15'],['Summer holiday','2015-07-16','2015-08-26'],['Autumn break','2015-10-19','2015-10-30'] #2015
                          , ['Christmas break','2015-12-21','2016-01-01'],['Winter holiday','2016-01-29','2016-01-29'],['Easter holiday','2016-03-07','2016-03-18'],['Pentecost','2016-05-06','2016-05-06'],['Pentecost','2016-05-17','2016-05-20'],['Summer holiday','2016-07-21','2016-08-31'],['Autumn break','2016-10-17','2016-10-28'] #2016
                          , ['Christmas break','2016-12-27','2017-01-06'],['Winter holiday','2017-01-30','2017-01-30'],['Easter holiday','2017-03-06','2017-03-17'],['Pentecost','2017-05-22','2017-05-26'],['Summer holiday','2017-07-20','2017-08-30'],['Autumn break','2017-10-02','2017-10-02'],['Autumn break','2017-10-16','2017-10-27'] #2017
                          , ['Christmas break','2017-12-22','2018-01-05'],['Winter holiday','2018-02-02','2018-02-02'],['Easter holiday','2018-03-05','2018-03-16'],['Pentecost','2018-05-07','2018-05-11'],['Summer holiday','2018-07-05','2018-08-15'],['Autumn break','2018-10-01','2018-10-12'] #2018
                          , ['Christmas break','2018-12-20','2019-01-04'],['Winter holiday','2019-02-01','2019-02-01'],['Easter holiday','2019-03-04','2019-03-15'],['Pentecost','2019-05-17','2019-05-31'],['Summer holiday','2019-06-27','2019-08-07'],['Autumn break','2019-10-04','2019-10-18'] #2019
                          ]

german_HH_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_HH_school_holidays)
german_HH_school_holidays_dataframe['Country'] = 'DE'
german_HH_school_holidays_dataframe['School_holiday_zone'] = 'DE-HH'

german_MV_school_holidays = [['Christmas break','2014-12-22','2015-01-02'],['Winter holiday','2015-02-02','2015-02-14'],['Easter holiday','2015-03-30','2015-04-08'],['Pentecost','2015-05-22','2015-05-26'],['Summer holiday','2015-07-20','2015-08-29'],['Autumn break','2015-10-24','2015-10-30'] #2015
                          , ['Christmas break','2015-12-21','2016-01-02'],['Winter holiday','2016-02-01','2016-02-13'],['Easter holiday','2016-03-21','2016-03-30'],['Pentecost','2016-05-14','2016-05-17'],['Summer holiday','2016-07-25','2016-09-03'],['Autumn break','2016-10-24','2016-10-28'] #2016
                          , ['Christmas break','2016-12-22','2017-01-02'],['Winter holiday','2017-02-06','2017-02-18'],['Easter holiday','2017-04-10','2017-04-19'],['Pentecost','2017-06-02','2017-06-06'],['Summer holiday','2017-07-24','2017-09-02'],['Autumn break','2017-10-02','2017-10-02'],['Autumn break','2017-10-23','2017-10-30'] #2017
                          , ['Christmas break','2017-12-21','2018-01-03'],['Winter holiday','2018-02-05','2018-02-16'],['Easter holiday','2018-03-26','2018-04-04'],['Pentecost','2018-05-11','2018-05-11'],['Pentecost','2018-05-18','2018-05-22'],['Summer holiday','2018-07-09','2018-08-18'],['Autumn break','2018-10-08','2018-10-13'],['Autumn break','2018-11-01','2018-11-02'] #2018
                          , ['Christmas break','2018-12-24','2019-01-05'],['Winter holiday','2019-02-04','2019-02-15'],['Easter holiday','2019-04-15','2019-04-24'],['Pentecost','2019-05-31','2019-05-31'],['Pentecost','2019-06-07','2019-06-11'],['Summer holiday','2019-07-01','2019-08-10'],['Autumn break','2019-10-04','2019-10-04'],['Autumn break','2019-10-07','2019-10-12'],['Autumn break','2019-11-01','2019-11-01'] #2019
                          ]

german_MV_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_MV_school_holidays)
german_MV_school_holidays_dataframe['Country'] = 'DE'
german_MV_school_holidays_dataframe['School_holiday_zone'] = 'DE-MV'

german_NI_school_holidays = [['Christmas break','2014-12-22','2015-01-05'],['Winter holiday','2015-02-02','2015-02-03'],['Easter holiday','2015-03-25','2015-04-10'],['Pentecost','2015-05-15','2015-05-15'],['Pentecost','2015-05-26','2015-05-26'],['Summer holiday','2015-07-23','2015-09-02'],['Autumn break','2015-10-19','2015-10-31'] #2015
                          , ['Christmas break','2015-12-23','2016-01-06'],['Winter holiday','2016-01-28','2016-01-29'],['Easter holiday','2016-03-18','2016-04-02'],['Pentecost','2016-05-06','2016-05-06'],['Pentecost','2016-05-17','2016-05-17'],['Summer holiday','2016-06-23','2016-08-03'],['Autumn break','2016-10-04','2016-10-15'] #2016
                          , ['Christmas break','2016-12-21','2017-01-06'],['Winter holiday','2017-01-30','2017-01-31'],['Easter holiday','2017-04-10','2017-04-22'],['Pentecost','2017-05-26','2017-05-26'],['Pentecost','2017-06-06','2017-06-06'],['Summer holiday','2017-06-22','2017-08-02'],['Autumn break','2017-10-02','2017-10-13'],['Autumn break','2017-10-30','2017-10-30'] #2017
                          , ['Christmas break','2017-12-22','2018-01-05'],['Winter holiday','2018-02-01','2018-02-02'],['Easter holiday','2018-03-19','2018-04-03'],['Pentecost','2018-04-30','2018-04-30'],['Summer holiday','2018-06-28','2018-08-08'],['Autumn break','2018-10-01','2018-10-12'] #2018
                          , ['Christmas break','2018-12-24','2019-01-04'],['Winter holiday','2019-01-31','2019-02-01'],['Easter holiday','2019-04-08','2019-04-23'],['Pentecost','2019-05-31','2019-05-31'],['Summer holiday','2019-07-04','2019-08-14'],['Autumn break','2019-10-04','2019-10-18'] #2019
                          ]

german_NI_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_NI_school_holidays)
german_NI_school_holidays_dataframe['Country'] = 'DE'
german_NI_school_holidays_dataframe['School_holiday_zone'] = 'DE-NI'

german_NW_school_holidays = [['Christmas break','2014-12-22','2015-01-06'],['Easter holiday','2015-03-30','2015-04-11'],['Pentecost','2015-05-26','2015-05-26'],['Summer holiday','2015-06-29','2015-08-11'],['Autumn break','2015-10-05','2015-10-17'] #2015
                          , ['Christmas break','2015-12-23','2016-01-06'],['Easter holiday','2016-03-21','2016-04-02'],['Pentecost','2016-05-17','2016-05-17'],['Summer holiday','2016-07-11','2016-08-23'],['Autumn break','2016-10-10','2016-10-21'] #2016
                          , ['Christmas break','2016-12-23','2017-01-06'],['Easter holiday','2017-04-10','2017-04-22'],['Pentecost','2017-06-06','2017-06-06'],['Summer holiday','2017-07-17','2017-08-29'],['Autumn break','2017-10-23','2017-11-04'] #2017
                          , ['Christmas break','2017-12-27','2018-01-06'],['Easter holiday','2018-03-26','2018-04-07'],['Pentecost','2018-05-22','2018-05-25'],['Summer holiday','2018-07-16','2018-08-28'],['Autumn break','2018-10-15','2018-10-27'] #2018
                          , ['Christmas break','2018-12-21','2019-01-04'],['Easter holiday','2019-04-15','2019-04-27'],['Pentecost','2019-06-11','2019-06-11'],['Summer holiday','2019-07-15','2019-08-27'],['Autumn break','2019-10-14','2019-10-26'] #2019
                          ]

german_NW_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_NW_school_holidays)
german_NW_school_holidays_dataframe['Country'] = 'DE'
german_NW_school_holidays_dataframe['School_holiday_zone'] = 'DE-NW'

german_RP_school_holidays = [['Christmas break','2014-12-22','2015-01-06'],['Easter holiday','2015-03-26','2015-04-10'],['Summer holiday','2015-07-27','2015-09-04'],['Autumn break','2015-10-19','2015-10-30'] #2015
                          , ['Christmas break','2015-12-23','2016-01-08'],['Easter holiday','2016-03-18','2016-04-01'],['Summer holiday','2016-07-18','2016-08-26'],['Autumn break','2016-10-10','2016-10-21'] #2016
                          , ['Christmas break','2016-12-22','2017-01-06'],['Easter holiday','2017-04-10','2017-04-21'],['Summer holiday','2017-07-03','2017-08-11'],['Autumn break','2017-10-02','2017-10-13'] #2017
                          , ['Christmas break','2017-12-22','2018-01-09'],['Easter holiday','2018-03-26','2018-04-06'],['Summer holiday','2018-06-25','2018-08-03'],['Autumn break','2018-10-01','2018-10-12'] #2018
                          , ['Christmas break','2018-12-20','2019-01-04'],['Winter holiday','2019-02-25','2019-03-01'],['Easter holiday','2019-04-23','2019-04-30'],['Summer holiday','2019-07-01','2019-08-01'],['Autumn break','2019-09-30','2019-10-11'] #2019
                          ]

german_RP_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_RP_school_holidays)
german_RP_school_holidays_dataframe['Country'] = 'DE'
german_RP_school_holidays_dataframe['School_holiday_zone'] = 'DE-RP'

german_SH_school_holidays = [['Christmas break','2014-12-22','2015-01-06'],['Easter holiday','2015-04-01','2015-04-17'],['Pentecost','2015-05-15','2015-05-15'],['Summer holiday','2015-07-20','2015-08-29'],['Autumn break','2015-10-19','2015-10-31'] #2015
                          , ['Christmas break','2015-12-21','2016-01-06'],['Easter holiday','2016-03-24','2016-04-09'],['Pentecost','2016-05-06','2016-05-06'],['Summer holiday','2016-07-25','2016-09-03'],['Autumn break','2016-10-17','2016-10-29'] #2016
                          , ['Christmas break','2016-12-23','2017-01-06'],['Easter holiday','2017-04-07','2017-04-21'],['Pentecost','2017-05-26','2017-05-26'],['Summer holiday','2017-07-24','2017-09-02'],['Autumn break','2017-10-16','2017-10-27'] #2017
                          , ['Christmas break','2017-12-21','2018-01-06'],['Easter holiday','2018-03-29','2018-04-13'],['Pentecost','2018-05-11','2018-05-11'],['Summer holiday','2018-07-09','2018-08-18'],['Autumn break','2018-10-01','2018-10-19'] #2018
                          , ['Christmas break','2018-12-21','2019-01-04'],['Easter holiday','2019-04-04','2019-04-18'],['Pentecost','2019-05-31','2019-05-31'],['Summer holiday','2019-07-01','2019-08-10'],['Autumn break','2019-10-04','2019-10-18']#2019
                          ]

german_SH_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_SH_school_holidays)
german_SH_school_holidays_dataframe['Country'] = 'DE'
german_SH_school_holidays_dataframe['School_holiday_zone'] = 'DE-SH'

german_SL_school_holidays = [['Christmas break','2014-12-22','2015-01-07'],['Winter holiday','2015-02-16','2015-02-21'],['Easter holiday','2015-03-30','2015-04-11'],['Summer holiday','2015-07-27','2015-09-05'],['Autumn break','2015-10-19','2015-10-31'] #2015
                          , ['Christmas break','2015-12-21','2016-01-02'],['Winter holiday','2016-02-08','2016-02-13'],['Easter holiday','2016-03-29','2016-04-09'],['Summer holiday','2016-07-18','2016-08-27'],['Autumn break','2016-10-10','2016-10-22'] #2016
                          , ['Christmas break','2016-12-19','2016-12-31'],['Winter holiday','2017-02-27','2017-03-04'],['Easter holiday','2017-04-10','2017-04-22'],['Summer holiday','2017-07-03','2017-08-14'],['Autumn break','2017-10-02','2017-10-14'] #2017
                          , ['Christmas break','2017-12-21','2018-01-05'],['Winter holiday','2018-02-12','2018-02-17'],['Easter holiday','2018-03-26','2018-04-06'],['Summer holiday','2018-06-25','2018-08-03'],['Autumn break','2018-10-01','2018-10-13'] #2018
                          , ['Christmas break','2018-12-22','2019-01-04'],['Winter holiday','2019-02-25','2019-03-05'],['Easter holiday','2019-04-17','2019-04-26'],['Summer holiday','2019-07-01','2019-08-09'],['Autumn break','2019-10-07','2019-10-18'] #2019
                          ]

german_SL_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_SL_school_holidays)
german_SL_school_holidays_dataframe['Country'] = 'DE'
german_SL_school_holidays_dataframe['School_holiday_zone'] = 'DE-SL'

german_SN_school_holidays = [['Christmas break','2014-12-22','2015-01-05'],['Winter holiday','2015-02-09','2015-02-21'],['Easter holiday','2015-04-02','2015-04-11'],['Pentecost','2015-05-15','2015-05-15'],['Summer holiday','2015-07-13','2015-08-21'],['Autumn break','2015-10-12','2015-10-24'] #2015
                          , ['Christmas break','2015-12-21','2016-01-02'],['Winter holiday','2016-02-08','2016-02-20'],['Easter holiday','2016-03-25','2016-04-02'],['Pentecost','2016-05-06','2016-05-06'],['Summer holiday','2016-06-27','2016-08-05'],['Autumn break','2016-10-03','2016-10-15'] #2016
                          , ['Christmas break','2016-12-23','2017-01-02'],['Winter holiday','2017-02-13','2017-02-24'],['Easter holiday','2017-04-13','2017-04-22'],['Pentecost','2017-05-26','2017-05-26'],['Summer holiday','2017-06-26','2017-08-04'],['Autumn break','2017-10-02','2017-10-14'],['Autumn break','2017-10-30','2017-10-30'] #2017
                          , ['Christmas break','2017-12-23','2018-01-02'],['Winter holiday','2018-02-12','2018-02-23'],['Easter holiday','2018-03-29','2018-04-06'],['Pentecost','2018-05-11','2018-05-11'],['Summer holiday','2018-07-02','2018-08-10'],['Autumn break','2018-10-08','2018-10-20'] #2018
                          , ['Christmas break','2018-12-22','2019-01-04'],['Winter holiday','2019-02-18','2019-03-02'],['Easter holiday','2019-04-19','2019-04-26'],['Pentecost','2019-05-31','2019-05-31'],['Summer holiday','2019-07-08','2019-08-16'],['Autumn break','2019-10-14','2019-10-25'] #2019
                          ]

german_SN_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_SN_school_holidays)
german_SN_school_holidays_dataframe['Country'] = 'DE'
german_SN_school_holidays_dataframe['School_holiday_zone'] = 'DE-SN'

german_ST_school_holidays = [['Christmas break','2014-12-22','2015-01-05'],['Winter holiday','2015-02-02','2015-02-14'],['Easter holiday','2015-04-02','2015-04-02'],['Pentecost','2015-05-15','2015-05-23'],['Summer holiday','2015-07-13','2015-08-26'],['Autumn break','2015-10-17','2015-10-24'] #2015
                          , ['Christmas break','2015-12-21','2016-01-05'],['Winter holiday','2016-02-01','2016-02-10'],['Easter holiday','2016-03-24','2016-03-24'],['Pentecost','2016-05-06','2016-05-14'],['Summer holiday','2016-06-27','2016-08-10'],['Autumn break','2016-10-04','2016-10-15'] #2016
                          , ['Christmas break','2016-12-19','2017-01-02'],['Winter holiday','2017-02-04','2017-02-11'],['Easter holiday','2017-04-10','2017-04-13'],['Pentecost','2017-05-26','2017-05-26'],['Summer holiday','2017-06-26','2017-08-09'],['Autumn break','2017-10-02','2017-10-13'],['Autumn break','2017-10-30','2017-10-30'] #2017
                          , ['Christmas break','2017-12-21','2018-01-03'],['Winter holiday','2018-02-05','2018-02-09'],['Easter holiday','2018-03-26','2018-03-31'],['Pentecost','2018-05-11','2015-05-19'],['Summer holiday','2018-06-28','2018-08-08'],['Autumn break','2018-10-01','2018-10-12'] #2018
                          , ['Christmas break','2018-12-19','2019-01-04'],['Winter holiday','2019-02-11','2019-02-15'],['Easter holiday','2019-04-18','2019-04-30'],['Pentecost','2019-05-31','2019-06-01'],['Summer holiday','2019-07-04','2019-08-14'],['Autumn break','2019-10-04','2019-10-11'] #2019
                          ]

german_ST_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_ST_school_holidays)
german_ST_school_holidays_dataframe['Country'] = 'DE'
german_ST_school_holidays_dataframe['School_holiday_zone'] = 'DE-ST'

german_TH_school_holidays = [['Christmas break','2014-12-22','2015-01-03'],['Winter holiday','2015-02-02','2015-02-07'],['Easter holiday','2015-03-30','2015-04-11'],['Pentecost','2015-05-15','2015-05-15'],['Summer holiday','2015-07-13','2015-08-21'],['Autumn break','2015-10-05','2015-10-17'] #2015
                          , ['Christmas break','2015-12-23','2016-01-02'],['Winter holiday','2016-02-01','2016-02-06'],['Easter holiday','2016-03-24','2016-04-02'],['Pentecost','2016-05-06','2016-05-06'],['Summer holiday','2016-06-27','2016-08-10'],['Autumn break','2016-10-10','2016-10-22'] #2016
                          , ['Christmas break','2016-12-23','2016-12-31'],['Winter holiday','2017-02-06','2017-02-11'],['Easter holiday','2017-04-10','2017-04-21'],['Pentecost','2017-05-26','2017-05-26'],['Summer holiday','2017-06-26','2017-08-09'],['Autumn break','2017-10-02','2017-10-14'] #2017
                          , ['Christmas break','2017-12-22','2018-01-05'],['Winter holiday','2018-02-05','2018-02-09'],['Easter holiday','2018-03-26','2018-04-07'],['Pentecost','2018-05-11','2018-05-11'],['Summer holiday','2018-07-02','2018-08-11'],['Autumn break','2018-10-01','2018-10-13'] #2018
                          , ['Christmas break','2018-12-21','2019-01-04'],['Winter holiday','2019-02-11','2019-02-15'],['Easter holiday','2019-04-15','2019-04-27'],['Pentecost','2019-05-31','2019-05-31'],['Summer holiday','2019-07-08','2019-08-17'],['Autumn break','2019-10-07','2019-10-19'] #2019
                          ]

german_TH_school_holidays_dataframe = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data=german_TH_school_holidays)
german_TH_school_holidays_dataframe['Country'] = 'DE'
german_TH_school_holidays_dataframe['School_holiday_zone'] = 'DE-TH'

german_school_holidays_list = [german_BB_school_holidays_dataframe
                              ,german_BE_school_holidays_dataframe
                              ,german_BW_school_holidays_dataframe
                              ,german_BY_school_holidays_dataframe
                              ,german_HB_school_holidays_dataframe
                              ,german_HE_school_holidays_dataframe
                              ,german_HH_school_holidays_dataframe
                              ,german_MV_school_holidays_dataframe
                              ,german_NI_school_holidays_dataframe
                              ,german_NW_school_holidays_dataframe
                              ,german_RP_school_holidays_dataframe
                              ,german_SH_school_holidays_dataframe
                              ,german_SL_school_holidays_dataframe
                              ,german_SN_school_holidays_dataframe
                              ,german_ST_school_holidays_dataframe
                              ,german_TH_school_holidays_dataframe
                                ]

# concat the aforementioned dataframes into one
german_school_holidays = pd.concat(german_school_holidays_list, ignore_index=True)

# generate the dates between the start and end dates of the school holiday periods and then expand on these generated dates
german_school_holidays['Date'] = german_school_holidays.apply(lambda x: pd.date_range(start=x['Start_date'], end=x['End_date']), axis=1)
german_school_holidays = german_school_holidays.explode('Date').reset_index(drop=True)

# Forced to make a static dataset for Belgium school holidays due to no available external data source as python library or api
belgian_school_holidays = [['Christmas break','2014-12-22','2015-01-04'],['Spring break','2015-02-16','2015-02-22'],['Easter break','2015-04-06','2015-04-19'],['Ascension holiday','2015-05-14','2015-05-15'],['Summer holiday','2015-07-01','2015-08-31'],['Autumn break','2015-11-02','2015-11-08'] #2015
                          ,['Christmas break','2015-12-21','2016-01-03'],['Spring break','2016-02-08','2016-02-14'],['Easter break','2016-03-28','2016-04-10'],['Ascension holiday','2016-05-05','2016-05-06'],['Summer holiday','2016-07-01','2016-08-31'],['Autumn break','2016-10-31','2016-11-06'] #2016
                          ,['Christmas break','2016-12-26','2017-01-08'],['Spring break','2017-02-27','2017-03-05'],['Easter break','2017-04-03','2017-04-17'],['Ascension holiday','2017-05-25','2017-05-26'],['Summer holiday','2017-07-01','2017-08-31'],['Autumn break','2017-10-30','2017-11-05'] #2017
                          ,['Christmas break','2017-12-25','2018-01-07'],['Spring break','2018-02-12','2018-02-18'],['Easter break','2018-04-02','2018-04-15'],['Ascension holiday','2018-05-10','2018-05-13'],['Summer holiday','2018-07-01','2018-08-31'],['Autumn break','2018-10-29','2018-11-04'] #2018
                          ,['Christmas break','2018-12-24','2019-01-06'],['Spring break','2019-03-04','2019-03-10'],['Easter break','2019-04-08','2019-04-22'],['Ascension holiday','2019-05-30','2019-05-31'],['Summer holiday','2019-07-01','2019-08-31'],['Autumn break','2019-10-28','2019-11-03'] #2019
                          ,['Christmas break','2019-12-23','2020-01-05'],['Spring break','2020-02-24','2020-03-01'],['Easter break','2020-04-06','2020-04-19'],['Ascension holiday','2020-05-21','2020-05-22'],['Summer holiday','2020-07-01','2020-08-31'],['Autumn break','2020-11-02','2020-11-15'] #2020
                          ,['Christmas break','2020-12-21','2021-01-03'],['Spring break','2021-02-15','2021-02-21'],['Easter break','2021-04-05','2021-04-18'],['Ascension holiday','2021-05-13','2021-05-14'],['Summer holiday','2021-07-01','2021-08-31'],['Autumn break','2021-11-01','2021-11-07'] #2021
                          ,['Christmas break','2021-12-27','2022-01-09'],['Spring break','2022-02-28','2022-03-06'],['Easter break','2022-04-04','2022-04-18'],['Ascension holiday','2022-05-26','2022-05-27'],['Summer holiday','2022-07-01','2022-08-31'],['Autumn break','2022-10-31','2022-11-06'] #2022
                          ,['Christmas break','2022-12-26','2023-01-08'],['Spring break','2023-02-20','2023-02-26'],['Easter break','2023-04-03','2023-04-16'],['Ascension holiday','2023-05-18','2023-05-19'],['Summer holiday','2023-07-01','2023-08-31'],['Autumn break','2023-10-30','2023-11-05'],['Christmas break','2023-12-25','2024-01-07'] #2023
                          ]

belgian_school_holidays = pd.DataFrame(columns=['School_holiday','Start_date','End_date'], data = belgian_school_holidays)
belgian_school_holidays['Country'] = 'BE'

# generate the dates between the start and end dates of the school holiday periods and then expand on these generated dates
belgian_school_holidays['Date'] = belgian_school_holidays.apply(lambda x: pd.date_range(start=x['Start_date'], end=x['End_date']), axis=1)
belgian_school_holidays = belgian_school_holidays.explode('Date').reset_index(drop=True)


# Forced to make a static dataset for Spanish school holidays due to no available external data source as python library or api
spanish_AN_school_holidays = [
                             ['Christmas holidays','2014-12-20','2015-01-07'], ['Easter holidays','2015-03-30','2015-04-06'], ['Summer holidays','2015-06-23','2015-09-09'] #2015
                            ,['Christmas holidays','2015-12-23','2016-01-06'], ['Easter holidays','2016-03-19','2016-03-28'], ['Summer holidays','2016-06-23','2016-09-11'] #2016
                            ,['Christmas holidays','2016-12-23','2017-01-08'], ['Easter holidays','2017-04-08','2017-04-16'], ['Summer holidays','2017-06-23','2017-09-10'] #2017
                            ,['Christmas holidays','2017-12-23','2018-01-07'], ['Sport holiday','2018-02-24','2018-02-28'], ['Spring time holiday','2018-03-24','2018-04-01'], ['Summer holidays','2018-06-23','2018-09-09'] #2018
                            ,['Christmas holidays','2018-12-22','2019-01-07'], ['Sport holiday','2019-02-27','2019-01-07'], ['Spring time holiday','2019-04-13','2019-04-21'], ['Summer holidays','2019-06-22','2019-09-09'] #2019
                            ,['Christmas holidays','2019-12-21','2020-01-07'], ['Sport holiday', '2020-02-26','2020-03-01'], ['Spring time holiday','2020-04-04','2020-04-12'], ['Summer holidays','2020-06-23','2020-09-09'] #2020
                            ,['Christmas holidays','2020-12-24','2021-01-10'], ['Spring time holidays','2021-03-29','2021-04-04'], ['Summer holidays','2021-06-23','2021-09-09']  #2021
                            ,['Christmas holidays','2021-12-23','2022-01-09'], ['Spring time  holidays','2022-04-09','2022-04-17'], ['Summer holidays','2022-06-25','2022-09-11'], ['Christmas holidays','2022-12-24','2023-01-08'] #2022
                             ]
spanish_AN_school_holidays_dataframe = pd.DataFrame(spanish_AN_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_AN_school_holidays_dataframe['Country'] = 'ES'
spanish_AN_school_holidays_dataframe['Region'] = 'AN'
spanish_AN_school_holidays_dataframe['School_holiday_zone'] = 'AN'

spanish_AR_school_holidays = [
                             ['Christmas holidays','2014-12-24','2015-01-07'], ['Easter holidays','2015-03-30','2015-04-06'], ['Summer holidays','2015-06-25','2015-09-09'] #2015
                            ,['Christmas holidays','2015-12-24','2016-01-07'], ['Easter holidays','2016-03-24','2016-04-03'], ['Summer holidays','2016-06-24','2016-09-07'] #2016
                            ,['Christmas holidays','2016-12-23','2017-01-08'], ['Easter holidays','2017-04-10','2017-04-16'], ['Summer holidays','2017-06-24','2017-09-06'] #2017
                            ,['Christmas holidays','2017-12-22','2018-01-07'], ['Spring time holidays','2018-03-29','2018-04-08'], ['Summer holidays','2018-06-21','2018-09-09'] #2018
                            ,['Christmas holidays','2018-12-22','2019-01-07'], ['Spring time holidays', '2019-04-13','2019-04-23'], ['Summer holidays','2019-06-21','2019-09-09'] #2019
                            ,['Christmas holidays','2019-12-21','2020-01-06'], ['Spring time holidays','2020-04-06','2020-04-13'], ['Summer holidays','2020-06-20','2020-09-05'] #2020
                            ,['Christmas holidays','2020-12-23','2021-01-06'], ['Spring time holidays','2021-03-29','2021-04-05'], ['Summer holidays','2021-06-23','2021-09-07'] #2021
                            ,['Christmas holidays','2021-12-23','2022-01-07'], ['Spring time holidays','2022-04-11','2022-04-18'], ['Summer holidays','2022-06-23','2022-09-07'], ['Christmas Holidays','2022-12-22','2023-01-08'] #2022
                             ]
spanish_AR_school_holidays_dataframe = pd.DataFrame(spanish_AR_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_AR_school_holidays_dataframe['Country'] = 'ES'
spanish_AR_school_holidays_dataframe['Region'] = 'AR'
spanish_AR_school_holidays_dataframe['School_holiday_zone'] = 'AR'

spanish_AS_school_holidays = [
                             ['Christmas holidays','2014-12-22','2015-01-07'], ['Easter holidays','2015-03-30','2015-04-06'], ['Summer holidays','2015-06-20','2015-09-09'] #2015
                            ,['Christmas holidays','2015-12-24','2016-01-08'], ['Easter holidays','2016-03-25','2016-04-01'], ['Summer holidays','2016-06-21','2016-09-11'] #2016
                            ,['Christmas holidays','2016-12-23','2017-01-05'], ['Easter holidays','2017-04-07','2017-04-14'], ['Summer holidays','2017-06-20','2017-09-10'] #2017
                            ,['Christmas holidays','2017-12-23','2018-01-07'], ['Easter holidays','2018-03-29','2018-04-08'], ['Summer holidays','2018-06-22','2018-09-09'] #2018
                            ,['Christmas holidays','2018-12-22','2019-01-07'], ['Sport holiday', '2019-03-01','2019-03-05'],['Easter holidays','2019-04-13','2019-04-21'] ,['Summer holidays','2019-06-29','2019-09-09'] #2019
                            ,['Christmas holidays','2019-12-23','2020-01-07'], ['Sport holiday', '2020-02-21','2020-02-25'], ['Easter holidays','2020-04-06','2020-04-12'], ['Summer holidays','2020-07-01','2020-09-09'] #2020
                            ,['Christmas holidays','2020-12-23','2021-01-08'], ['Spring time holidays','2021-03-29','2021-04-05'], ['Summer holidays','2021-06-21','2021-09-08'] #2021
                            ,['Christmas holidays','2021-12-24','2022-01-09'], ['Sport holiday', '2022-02-25','2022-03-01'], ['Spring time holidays','2022-04-09','2022-04-17'], ['Summer holidays','2022-06-22','2022-09-11'], ['Christmas Holidays','2022-12-24','2023-01-08'] #2022
                             ]

spanish_AS_school_holidays_dataframe = pd.DataFrame(spanish_AR_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_AS_school_holidays_dataframe['Country'] = 'ES'
spanish_AS_school_holidays_dataframe['Region'] = 'AS'
spanish_AS_school_holidays_dataframe['School_holiday_zone'] = 'AS'

spanish_CB_school_holidays = [
                              ['Christmas holidays','2014-12-22','2015-01-07'], ['Carneval holidays','2015-02-16','2015-02-17'],['Easter holidays','2015-04-02','2015-04-10'], ['Summer holidays','2015-06-20','2015-09-09'] #2015
                             ,['Christmas holidays','2015-12-22','2016-01-09'], ['Carneval holidays','2016-02-08','2016-02-09'], ['Easter holidays','2016-03-23','2016-04-01'], ['Summer holidays','2016-06-22','2016-09-07'] #2016
                             ,['Christmas holidays','2016-12-24','2017-01-08'], ['Carneval holidays','2017-02-23','2017-02-28'], ['Easter holidays','2017-04-13','2017-04-23'], ['Summer holidays','2017-06-24','2017-09-06'], ['Autumn holidays', '2017-10-28','2017-11-05'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Carneval holidays','2018-02-22','2018-02-27'], ['Easter holidays','2018-03-29','2018-04-01'], ['Spring time holidays','2018-04-30','2018-05-06'], ['Summer holidays','2018-06-23','2018-09-02'], ['Autumn holidays', '2018-10-27','2018-11-04'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-06'], ['Carneval holidays', '2019-02-23','2019-03-03'], ['Easter holidays','2019-04-18','2019-04-28'] ,['Summer holidays','2019-06-22','2019-09-08'], ['Autumn holidays', '2019-10-28','2019-11-03'] #2019
                             ,['Christmas holidays','2019-12-23','2020-01-07'], ['Carneval holidays', '2020-02-24','2020-03-01'], ['Spring time holidays','2020-04-09','2020-04-19'], ['Summer holidays','2020-06-26','2020-09-06'], ['Autumn holidays','2020-11-02','2020-11-06'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-08'], ['Carneval holidays','2021-02-15','2021-02-17'], ['Spring time  holidays','2021-04-01','2021-04-09'], ['Summer holidays','2021-06-22','2021-06-09'], ['Autumn holidays','2021-11-01','2021-11-05']  #2021
                             ,['Christmas holidays','2021-12-24','2022-01-09'], ['Carneval holidays', '2022-02-19','2022-02-27'], ['Spring time holidays','2022-04-14','2022-04-24'], ['Summer holidays','2022-06-30','2022-09-06'], ['Autumn holidays','2022-10-31','2022-11-06'], ['Christmas Holidays','2022-12-24','2023-01-08'] #2022
                             ]

spanish_CB_school_holidays_dataframe = pd.DataFrame(spanish_CB_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_CB_school_holidays_dataframe['Country'] = 'ES'
spanish_CB_school_holidays_dataframe['Region'] = 'CB'
spanish_CB_school_holidays_dataframe['School_holiday_zone'] = 'CB'

spanish_CE_school_holidays = [
                              ['Christmas holidays','2014-12-22','2015-01-07'],['Easter holidays','2015-03-30','2015-04-06'], ['Summer holidays','2015-06-20','2015-09-09'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-06'], ['Easter holidays','2016-03-24','2016-04-04'], ['Summer holidays','2016-06-21','2016-09-09'] #2016
                             ,['Christmas holidays','2016-12-23','2017-01-08'], ['Easter holidays','2017-04-06','2017-04-16'], ['Summer holidays','2017-06-23','2017-09-10'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Spring time holidays','2018-03-24','2018-04-08'], ['Summer holidays','2018-06-23','2018-09-10'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-07'], ['Spring time holidays', '2019-04-15','2019-04-21'], ['Summer holidays','2019-06-22','2019-09-09'] #2019
                             ,['Christmas holidays','2019-12-23','2020-01-07'], ['Sport holiday', '2020-02-21','2020-02-24'], ['Spring time holidays','2020-03-28','2020-04-12'], ['Summer holidays','2020-06-23','2020-09-05'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-07'], ['Spring time holidays','2021-03-29','2021-04-09'], ['Summer holidays','2021-06-22','2021-09-09']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-09'], ['Spring time holidays','2022-04-02','2022-04-17'], ['Summer holidays','2022-06-23','2022-09-07'], ['Christmas Holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_CE_school_holidays_dataframe = pd.DataFrame(spanish_CE_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_CE_school_holidays_dataframe['Country'] = 'ES'
spanish_CE_school_holidays_dataframe['Region'] = 'CE'
spanish_CE_school_holidays_dataframe['School_holiday_zone'] = 'CE'

spanish_CL_school_holidays = [
                              ['Christmas holidays','2014-12-20','2015-01-07'], ['Carneval holidays','2015-02-16','2015-02-17'], ['Easter holidays','2015-03-28','2015-04-06'],['Summer holidays','2015-06-04','2015-09-09'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-07'], ['Carneval holidays','2016-02-08','2016-02-09'], ['Easter holidays','2016-03-19','2016-03-30'],['Summer holidays','2016-06-23','2016-09-11'] #2016
                             ,['Christmas holidays','2016-12-23','2017-01-08'], ['Carneval holidays','2017-02-27','2017-02-28'], ['Easter holidays','2017-04-06','2017-04-16'],['Summer holidays','2017-06-23','2017-09-10'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Carneval holidays','2018-02-10','2018-02-13'], ['Spring time holidays','2018-03-29','2018-04-01'], ['Summer holidays','2018-06-23','2018-09-09'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-07'], ['Carneval holidays', '2019-03-04','2019-03-05'], ['Easter holidays','2019-04-12','2019-04-23'], ['Summer holidays','2019-06-22','2019-09-08'], ['Autumn holidays','2019-10-30','2019-11-03'] #2019
                             ,['Christmas holidays','2019-12-21','2020-01-07'], ['Carneval holidays', '2020-02-24','2020-02-26'], ['Spring time holidays','2020-04-03','2020-04-13'], ['Summer holidays','2020-06-24','2020-09-05'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-10'], ['Sport holiday','2021-02-15','2021-02-16'], ['Spring time holidays','2021-03-26','2021-04-05'], ['Summer holidays','2021-06-23','2021-09-09']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-09'], ['Sport holiday','2022-02-28','2022-03-01'], ['Spring time holidays','2022-04-07','2022-04-17'], ['Summer holidays','2022-06-23','2022-09-08'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_CL_school_holidays_dataframe = pd.DataFrame(spanish_CL_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_CL_school_holidays_dataframe['Country'] = 'ES'
spanish_CL_school_holidays_dataframe['Region'] = 'CL'
spanish_CL_school_holidays_dataframe['School_holiday_zone'] = 'CL'

spanish_CM_school_holidays = [
                              ['Christmas holidays','2014-12-22','2015-01-07'], ['Carneval holidays','2015-02-16','2015-02-17'], ['Easter holidays','2015-03-30','2015-04-06'],['Summer holidays','2015-06-20','2015-09-06'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-08'], ['Carneval holidays','2016-02-08','2016-02-09'], ['Easter holidays','2016-03-21','2016-03-28'],['Summer holidays','2016-06-22','2016-09-11'] #2016
                             ,['Christmas holidays','2016-12-23','2017-01-06'], ['Carneval holidays','2017-02-27','2017-02-28'], ['Easter holidays','2017-04-10','2017-04-17'],['Summer holidays','2017-06-23','2017-09-10'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Carneval holidays','2018-01-12','2018-01-13'], ['Easter holidays','2018-03-24','2018-04-02'], ['Summer holidays','2018-06-22','2018-09-09'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-07'], ['Carneval holidays', '2019-02-08','2019-02-11'], ['Easter holidays','2019-04-15','2019-04-22'], ['Summer holidays','2019-06-22','2019-09-08'] #2019
                             ,['Christmas holidays','2019-12-23','2020-01-07'], ['Spring time holidays','2020-04-06','2020-04-13'], ['Summer holidays','2020-06-20','2020-09-06'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-07'], ['Sport holiday','2021-02-15','2021-02-16'], ['Spring time holidays','2021-03-29','2021-04-05'], ['Summer holidays','2021-06-23','2021-09-08']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-09'], ['Sport holiday','2022-02-28','2022-03-01'], ['Spring time holidays','2022-04-11','2022-04-18'], ['Summer holidays','2022-06-23','2022-09-07'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_CM_school_holidays_dataframe = pd.DataFrame(spanish_CM_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_CM_school_holidays_dataframe['Country'] = 'ES'
spanish_CM_school_holidays_dataframe['Region'] = 'CM'
spanish_CM_school_holidays_dataframe['School_holiday_zone'] = 'CM'

spanish_CN_school_holidays = [
                              ['Christmas holidays','2014-12-22','2015-01-07'], ['Easter holidays','2015-03-30','2015-04-05'],['Summer holidays','2015-06-20','2015-09-08'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-07'], ['Easter holidays','2016-03-21','2016-03-25'],['Summer holidays','2016-06-30','2016-09-08'] #2016
                             ,['Christmas holidays','2016-12-26','2017-01-06'], ['Easter holidays','2017-04-10','2017-04-14'],['Summer holidays','2017-06-22','2017-09-10'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Easter holidays','2018-03-24','2018-01-07'],['Summer holidays','2018-06-23','2018-09-09'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-07'], ['Spring time holidays','2019-04-15','2019-04-19'], ['Summer holidays','2019-06-23','2019-09-09'] #2019
                             ,['Christmas holidays','2019-12-23','2020-01-07'], ['Spring time holidays','2020-04-06','2020-04-10'], ['Summer holidays','2020-06-20','2020-09-14'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-07'], ['Spring time holidays','2021-03-29','2021-04-04'], ['Summer holidays','2021-06-23','2021-09-08']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-09'], ['Spring time holidays','2022-04-11','2022-04-15'], ['Summer holidays','2022-06-24','2022-09-08'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_CN_school_holidays_dataframe = pd.DataFrame(spanish_CN_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_CN_school_holidays_dataframe['Country'] = 'ES'
spanish_CN_school_holidays_dataframe['Region'] = 'CN'
spanish_CN_school_holidays_dataframe['School_holiday_zone'] = 'CN'

spanish_CT_school_holidays = [
                              ['Christmas holidays','2014-12-24','2015-01-07'], ['Easter holidays','2015-03-28','2015-04-06'],['Summer holidays','2015-06-20','2015-09-13'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-07'], ['Easter holidays','2016-03-19','2016-03-28'],['Summer holidays','2016-06-22','2016-09-11'] #2016
                             ,['Christmas holidays','2016-12-23','2017-01-08'], ['Easter holidays','2017-04-08','2017-04-17'],['Summer holidays','2017-06-22','2017-09-17'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Easter holidays','2018-03-24','2018-04-02'],['Summer holidays','2018-06-22','2018-09-11'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-07'], ['Easter holidays','2019-04-13','2019-04-22'], ['Summer holidays','2019-06-22','2019-09-11'] #2019
                             ,['Christmas holidays','2019-12-21','2020-01-07'], ['Easter holidays','2020-04-04','2020-04-13'], ['Summer holidays','2020-06-20','2020-09-13'] #2020
                             ,['Christmas holidays','2020-12-22','2021-01-07'], ['Easter holidays','2021-03-27','2021-04-05'], ['Summer holidays','2021-06-23','2021-09-12']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-09'], ['Easter holidays','2022-04-11','2022-04-18'], ['Summer holidays','2022-06-23','2022-09-04'], ['Christmas holidays','2022-12-22','2023-01-08'] #2022
                             ]

spanish_CT_school_holidays_dataframe = pd.DataFrame(spanish_CT_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_CT_school_holidays_dataframe['Country'] = 'ES'
spanish_CT_school_holidays_dataframe['Region'] = 'CT'
spanish_CT_school_holidays_dataframe['School_holiday_zone'] = 'CT'

spanish_EX_school_holidays = [
                              ['Christmas holidays','2014-12-22','2015-01-07'], ['Carneval holidays','2015-02-16','2015-02-17'], ['Easter holidays','2015-03-30','2015-04-06'],['Summer holidays','2015-06-20','2015-09-15'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-07'], ['Carneval holidays','2016-02-08','2016-02-09'], ['Easter holidays','2016-03-21','2016-03-28'],['Summer holidays','2016-06-20','2016-09-12'] #2016
                             ,['Christmas holidays','2016-12-23','2017-01-06'], ['Carneval holidays','2017-02-27','2017-02-28'], ['Easter holidays','2017-04-10','2017-04-17'],['Summer holidays','2017-06-21','2017-09-17'] , ['Autumn holidays','2017-10-12','2017-10-15']#2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Winter holidays','2018-02-10','2018-02-13'], ['Easter holidays','2018-03-24','2018-04-02'],['Summer holidays','2018-06-22','2018-09-11'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-07'], ['Easter holidays','2019-04-15','2019-04-22'],['Summer holidays','2019-06-22','2019-09-09'] #2019
                             ,['Christmas holidays','2019-12-23','2020-01-07'], ['Sport holiday','2020-02-24','2020-02-25'], ['Spring time holidays','2020-04-06','2020-04-13'],['Summer holidays','2020-07-25','2020-09-09'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-08'], ['Carneval holidays','2021-02-15','2021-02-16'], ['Spring time holidays','2021-03-29','2021-04-05'],['Summer holidays','2021-06-18','2021-09-09']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-07'], ['Carneval holidays','2022-02-28','2022-03-01'], ['Easter holidays','2022-04-11','2022-04-18'],['Summer holidays','2022-06-23','2022-09-11'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_EX_school_holidays_dataframe = pd.DataFrame(spanish_EX_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_EX_school_holidays_dataframe['Country'] = 'ES'
spanish_EX_school_holidays_dataframe['Region'] = 'EX'
spanish_EX_school_holidays_dataframe['School_holiday_zone'] = 'EX'

spanish_GA_school_holidays = [
                              ['Christmas holidays','2014-12-22','2015-01-07'], ['Carneval holidays','2015-02-16','2015-02-18'], ['Easter holidays','2015-03-30','2015-04-06'],['Summer holidays','2015-06-20','2015-09-11'] #2015
                             ,['Christmas holidays','2015-12-21','2016-01-06'], ['Carneval holidays','2016-02-08','2016-02-10'], ['Easter holidays','2016-03-21','2016-03-28'],['Summer holidays','2016-06-22','2016-09-12'] #2016
                             ,['Christmas holidays','2016-12-22','2017-01-06'], ['Carneval holidays','2017-02-27','2017-03-01'], ['Easter holidays','2017-04-10','2017-04-17'],['Summer holidays','2017-06-24','2017-09-10'] #2017
                             ,['Christmas holidays','2017-12-22','2018-01-07'], ['Carneval holidays','2018-02-10','2018-02-18'], ['Easter holidays','2018-03-24','2018-04-02'],['Summer holidays','2018-06-22','2018-09-11'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-07'], ['Carneval holidays','2019-03-04','2019-03-06'], ['Easter holidays','2019-04-13','2019-04-22'],['Summer holidays','2019-06-22','2019-12-08'] #2019
                             ,['Christmas holidays','2019-12-21','2020-01-07'], ['Sport holiday','2020-02-24','2020-02-25'], ['Spring time holidays','2020-04-04','2020-04-13'],['Summer holidays','2020-06-20','2020-09-09'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-07'], ['Carneval holidays','2021-02-15','2021-02-17'], ['Spring time holidays','2021-03-27','2021-04-05'],['Summer holidays','2021-06-23','2021-09-08']  #2021
                             ,['Christmas holidays','2021-12-22','2022-01-07'], ['Carneval holidays','2022-02-28','2022-03-02'], ['Easter holidays','2022-04-11','2022-04-18'],['Summer holidays','2022-06-23','2022-09-07'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_GA_school_holidays_dataframe = pd.DataFrame(spanish_GA_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_GA_school_holidays_dataframe['Country'] = 'ES'
spanish_GA_school_holidays_dataframe['Region'] = 'GA'
spanish_GA_school_holidays_dataframe['School_holiday_zone'] = 'GA'

spanish_IB_school_holidays = [
                              ['Christmas holidays','2014-12-23','2015-01-07'], ['Easter holidays','2015-04-02','2015-04-07'],['Summer holidays','2015-06-20','2015-09-11'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-07'], ['Easter holidays','2016-03-24','2016-04-01'],['Summer holidays','2016-06-23','2016-09-11'] #2016
                             ,['Christmas holidays','2016-12-23','2017-01-08'], ['Easter holidays','2017-04-13','2017-04-23'],['Summer holidays','2017-06-23','2017-09-11'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Easter holidays','2018-03-29','2018-04-08'],['Summer holidays','2018-06-23','2018-09-11'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-06'], ['Sport holiday','2019-02-28','2019-03-03'], ['Easter holidays','2019-04-18','2019-04-28'],['Summer holidays','2019-06-22','2019-09-10'] #2019
                             ,['Christmas holidays','2019-12-23','2020-01-07'], ['Sport holiday','2020-02-28','2020-03-01'], ['Spring time holidays','2020-04-09','2020-04-19'],['Summer holidays','2020-06-20','2020-09-09'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-07'], ['Spring time holidays','2021-04-01','2021-04-11'],['Summer holidays','2021-06-22','2021-09-08']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-09'], ['Sport holiday','2022-02-26','2022-03-01'], ['Spring time holidays','2022-04-14','2022-04-24'],['Summer holidays','2022-06-30','2022-09-11'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_IB_school_holidays_dataframe = pd.DataFrame(spanish_IB_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_IB_school_holidays_dataframe['Country'] = 'ES'
spanish_IB_school_holidays_dataframe['Region'] = 'IB'
spanish_IB_school_holidays_dataframe['School_holiday_zone'] = 'IB'

spanish_MC_school_holidays = [
                              ['Christmas holidays','2014-12-23','2015-01-06'], ['Easter holidays','2015-03-30','2015-04-06'],['Summer holidays','2015-06-20','2015-09-07'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-06'], ['Easter holidays','2016-03-21','2016-03-29'],['Summer holidays','2016-06-21','2016-09-06'] #2016
                             ,['Christmas holidays','2016-12-24','2017-01-06'], ['Easter holidays','2017-04-10','2017-04-14'],['Summer holidays','2017-06-22','2017-09-06'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Easter holidays','2018-03-26','2018-04-03'],['Spring time holidays','2018-04-30','2018-05-04'], ['Summer holidays','2018-06-23','2018-09-04'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-06'], ['Easter holidays','2019-04-15','2019-04-19'],['Summer holidays','2019-06-22','2019-09-05'] #2019
                             ,['Christmas holidays','2019-12-21','2020-01-06'], ['Easter holidays','2020-04-06','2020-04-10'],['Summer holidays','2020-06-20','2020-09-06'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-08'], ['Spring time holidays','2021-03-29','2021-04-06'],['May holidays','2021-04-30','2021-05-04'],['Summer holidays','2021-06-23','2021-09-06']  #2021
                             ,['Christmas holidays','2021-12-24','2022-01-06'], ['Easter holidays','2022-04-11','2022-04-15'],['Summer holidays','2022-06-23','2022-09-07'], ['Christmas holidays','2022-12-24','2023-01-08'] #2022
                             ]

spanish_MC_school_holidays_dataframe = pd.DataFrame(spanish_MC_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_MC_school_holidays_dataframe['Country'] = 'ES'
spanish_MC_school_holidays_dataframe['Region'] = 'MC'
spanish_MC_school_holidays_dataframe['School_holiday_zone'] = 'MC'

spanish_MD_school_holidays = [
                              ['Christmas holidays','2014-12-20','2015-01-07'], ['Easter holidays','2015-03-27','2015-04-06'],['Summer holidays','2015-06-20','2015-09-07'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-06'], ['Easter holidays','2016-03-19','2016-03-28'],['Summer holidays','2016-06-22','2016-09-08'] #2016
                             ,['Christmas holidays','2016-12-23','2017-01-08'], ['Easter holidays','2017-04-07','2017-04-17'],['Summer holidays','2017-06-23','2017-09-06'],['Autumn holidays','2017-10-12','2017-10-15'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Carneval holidays','2018-02-15','2018-02-18'], ['Spring time holidays','2018-03-23','2018-04-02'], ['Summer holidays','2018-06-23','2018-09-06'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-07'], ['Carneval holidays','2019-03-01','2019-03-04'], ['Easter holidays','2019-04-12','2019-04-22'],['Summer holidays','2019-06-22','2019-09-06'] #2019
                             ,['Christmas holidays','2019-12-22','2020-01-06'], ['Easter holidays','2020-04-09','2020-04-16'],['Summer holidays','2020-07-01','2020-09-07'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-08'], ['Sport holiday','2021-02-19','2021-02-22'], ['Spring time holidays','2021-03-26','2021-04-05'],['Summer holidays','2021-06-22','2021-09-06']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-09'], ['Sport holiday','2022-02-25','2022-02-28'] ,['Spring time holidays','2022-04-08','2022-04-18'],['Summer holidays','2022-06-24','2022-09-06'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_MD_school_holidays_dataframe = pd.DataFrame(spanish_MD_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_MD_school_holidays_dataframe['Country'] = 'ES'
spanish_MD_school_holidays_dataframe['Region'] = 'MD'
spanish_MD_school_holidays_dataframe['School_holiday_zone'] = 'MD'

spanish_NC_school_holidays = [
                              ['Christmas holidays','2014-12-20','2015-01-07'], ['Easter holidays','2015-04-02','2015-04-12'],['Summer holidays','2015-06-20','2015-09-10'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-07'], ['Easter holidays','2016-03-24','2016-04-03'],['Summer holidays','2016-06-22','2016-09-07'] #2016
                             ,['Christmas holidays','2016-12-23','2017-01-08'], ['Easter holidays','2017-04-13','2017-04-23'],['Summer holidays','2017-06-30','2017-09-10'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-08'], ['Easter holidays','2018-03-29','2018-04-08'],['Summer holidays','2018-06-22','2018-09-09'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-07'], ['Easter holidays','2019-04-18','2019-04-28'],['Summer holidays','2019-06-22','2019-09-06'] #2019
                             ,['Christmas holidays','2019-12-21','2020-01-07'], ['Easter holidays','2020-04-09','2020-04-19'],['Summer holidays','2020-06-17','2020-09-05'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-08'], ['Easter holidays','2021-04-01','2021-04-11'],['Summer holidays','2021-06-21','2021-09-08']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-09'], ['Easter holidays','2022-04-14','2022-04-24'],['Summer holidays','2022-06-22','2022-09-08'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_NC_school_holidays_dataframe = pd.DataFrame(spanish_NC_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_NC_school_holidays_dataframe['Country'] = 'ES'
spanish_NC_school_holidays_dataframe['Region'] = 'NC'
spanish_NC_school_holidays_dataframe['School_holiday_zone'] = 'NC'

spanish_PV_school_holidays = [
                              ['Christmas holidays','2014-12-24','2015-01-06'], ['Easter holidays','2015-04-02','2015-04-06'],['Summer holidays','2015-06-04','2015-09-07'] #2015
                             ,['Christmas holidays','2015-12-24','2016-01-06'], ['Easter holidays','2016-03-24','2016-03-28'],['Summer holidays','2016-06-24','2016-09-09'] #2016
                             ,['Christmas holidays','2016-12-24','2017-01-06'], ['Easter holidays','2017-04-13','2017-04-17'],['Summer holidays','2017-06-23','2017-09-08'] #2017
                             ,['Christmas holidays','2017-12-24','2018-01-07'], ['Easter holidays','2018-03-29','2018-04-02'],['Summer holidays','2018-06-03','2018-09-06'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-06'], ['Sport holiday','2019-02-28','2019-03-03'],['Easter holidays','2019-04-18','2019-04-22'],['Summer holidays','2019-06-22','2019-09-10'] #2019
                             ,['Christmas holidays','2019-12-21','2020-01-07'], ['Sport holiday','2020-02-28','2020-03-01'], ['Easter holidays','2020-04-09','2020-04-19'],['Summer holidays','2020-06-20','2020-09-06'] #2020
                             ,['Christmas holidays','2020-12-24','2021-01-08'], ['Carneval holidays','2021-02-11','2021-02-17'],['Sport holiday','2021-02-18','2021-02-28'],['Easter holidays','2021-04-01','2021-04-05'],['Spring time holidays','2021-04-13','2021-04-17'],['Summer holidays','2021-06-18','2021-09-08']  #2021
                             ,['Christmas holidays','2021-12-24','2022-01-06'], ['Sport holiday','2022-02-17','2022-02-20'],['Easter holidays','2022-04-14','2022-04-18'],['Summer holidays','2022-06-22','2022-09-11'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_PV_school_holidays_dataframe = pd.DataFrame(spanish_PV_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_PV_school_holidays_dataframe['Country'] = 'ES'
spanish_PV_school_holidays_dataframe['Region'] = 'PV'
spanish_PV_school_holidays_dataframe['School_holiday_zone'] = 'PV'

spanish_RI_school_holidays = [
                              ['Christmas holidays','2014-12-22','2015-01-07'], ['Easter holidays','2015-04-02','2015-04-10'],['Summer holidays','2015-06-24','2015-09-10'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-08'], ['Easter holidays','2016-03-24','2016-04-01'],['Summer holidays','2016-06-26','2016-09-08'] #2016
                             ,['Christmas holidays','2016-12-26','2017-01-06'], ['Easter holidays','2017-04-13','2017-04-21'],['Summer holidays','2017-06-24','2017-09-06'] #2017
                             ,['Christmas holidays','2017-12-25','2018-01-06'], ['Easter holidays','2018-03-29','2018-04-06'],['Summer holidays','2018-06-22','2018-09-05'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-07'], ['Easter holidays','2019-04-18','2019-04-26'],['Summer holidays','2019-06-22','2019-09-01'] #2019
                             ,['Christmas holidays','2019-12-23','2020-01-07'], ['Easter holidays','2020-04-09','2020-04-17'],['Summer holidays','2020-07-01','2020-09-06'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-10'], ['Easter holidays','2021-04-01','2021-04-11'],['Summer holidays','2021-06-22','2021-09-05']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-09'], ['Easter holidays','2022-04-09','2022-04-17'],['Summer holidays','2022-06-25','2022-09-07'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_RI_school_holidays_dataframe = pd.DataFrame(spanish_RI_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_RI_school_holidays_dataframe['Country'] = 'ES'
spanish_RI_school_holidays_dataframe['Region'] = 'RI'
spanish_RI_school_holidays_dataframe['School_holiday_zone'] = 'RI'

spanish_VC_school_holidays = [
                              ['Christmas holidays','2014-12-23','2015-01-06'], ['Easter holidays','2015-04-02','2015-04-13'],['Summer holidays','2015-06-20','2015-09-09'] #2015
                             ,['Christmas holidays','2015-12-23','2016-01-06'], ['Easter holidays','2016-03-24','2016-04-04'],['Summer holidays','2016-06-22','2016-09-07'] #2016
                             ,['Christmas holidays','2016-12-23','2017-01-06'], ['Easter holidays','2017-04-13','2017-04-24'],['Summer holidays','2017-06-20','2017-09-10'] #2017
                             ,['Christmas holidays','2017-12-23','2018-01-07'], ['Easter holidays','2018-03-29','2018-04-09'],['Summer holidays','2018-06-22','2018-09-09'] #2018
                             ,['Christmas holidays','2018-12-22','2019-01-06'], ['Easter holidays','2019-04-18','2019-04-29'],['Summer holidays','2019-06-01','2019-09-08'] #2019
                             ,['Christmas holidays','2019-12-23','2020-01-06'], ['Easter holidays','2020-04-09','2020-04-20'],['Summer holidays','2020-06-17','2020-09-06'] #2020
                             ,['Christmas holidays','2020-12-23','2021-01-06'], ['Easter holidays','2021-04-01','2021-04-12'],['Summer holidays','2021-06-24','2021-09-07']  #2021
                             ,['Christmas holidays','2021-12-23','2022-01-09'], ['Easter holidays','2022-04-14','2022-04-25'],['Summer holidays','2022-06-22','2022-09-11'], ['Christmas holidays','2022-12-23','2023-01-08'] #2022
                             ]

spanish_VC_school_holidays_dataframe = pd.DataFrame(spanish_VC_school_holidays,columns =['School_holiday','Start_date','End_date'])
spanish_VC_school_holidays_dataframe['Country'] = 'ES'
spanish_VC_school_holidays_dataframe['Region'] = 'VC'
spanish_VC_school_holidays_dataframe['School_holiday_zone'] = 'VC'

spanish_school_holidays_list = [spanish_AN_school_holidays_dataframe
                               , spanish_AR_school_holidays_dataframe
                               , spanish_AS_school_holidays_dataframe
                               , spanish_CB_school_holidays_dataframe
                               , spanish_CE_school_holidays_dataframe
                               , spanish_CL_school_holidays_dataframe
                               , spanish_CM_school_holidays_dataframe
                               , spanish_CN_school_holidays_dataframe
                               , spanish_CT_school_holidays_dataframe
                               , spanish_EX_school_holidays_dataframe
                               , spanish_GA_school_holidays_dataframe
                               , spanish_IB_school_holidays_dataframe
                               , spanish_MC_school_holidays_dataframe
                               , spanish_MD_school_holidays_dataframe
                               , spanish_NC_school_holidays_dataframe
                               , spanish_PV_school_holidays_dataframe
                               , spanish_RI_school_holidays_dataframe
                               , spanish_VC_school_holidays_dataframe
                                ]

# concat the aforementioned dataframes into one
spanish_school_holidays = pd.concat(spanish_school_holidays_list, ignore_index=True)

# generate the dates between the start and end dates of the school holiday periods and then expand on these generated dates
spanish_school_holidays['Date'] = spanish_school_holidays.apply(lambda x: pd.date_range(start=x['Start_date'], end=x['End_date']), axis=1)
spanish_school_holidays = spanish_school_holidays.explode('Date').reset_index(drop=True)

# add the missing dutch, french, belgian and spanish school holidays to the dataframe with school holidays generated by the api for Germany, France, and the Netherlands
countries_and_school_zones_with_school_holidays = countries_and_school_zones_with_school_holidays.append(belgian_school_holidays, ignore_index=True)
countries_and_school_zones_with_school_holidays = countries_and_school_zones_with_school_holidays.append(spanish_school_holidays, ignore_index=True)
countries_and_school_zones_with_school_holidays = countries_and_school_zones_with_school_holidays.append(dutch_school_holidays, ignore_index=True)
countries_and_school_zones_with_school_holidays = countries_and_school_zones_with_school_holidays.append(french_school_holidays, ignore_index=True)
external_variables_per_country_and_school_holiday_zone = countries_and_school_zones_with_school_holidays.append(german_school_holidays, ignore_index=True)

# for science statistics purposes, turn school holidays into numeric variables
"""Avoid double astypes (e.g. .replace({"True": 1, "False:0}).astype(int), this makes clear what 1 and 0 is."""
external_variables_per_country_and_school_holiday_zone['School_holiday'] = external_variables_per_country_and_school_holiday_zone['School_holiday'].astype('bool').astype('int')

# add the dataframe of school holidays per school holiday zone per country to the generated date range dataframe
external_variables_per_country_and_school_holiday_zone = pd.merge(countries_and_school_zones_with_dates, external_variables_per_country_and_school_holiday_zone, how='left', on=['Country', 'School_holiday_zone', 'Date'])
external_variables_per_country_and_school_holiday_zone = external_variables_per_country_and_school_holiday_zone[['Country', 'School_holiday_zone', 'Date', 'CalendarKey', 'School_holiday']]
external_variables_per_country_and_school_holiday_zone['School_holiday'].fillna(0, inplace=True)
external_variables_per_country_and_school_holiday_zone['School_holiday'] = external_variables_per_country_and_school_holiday_zone['School_holiday'].astype(int)

#turn nan values to None so SQL takes it as NULL
external_variables_per_country_and_school_holiday_zone = external_variables_per_country_and_school_holiday_zone.replace(np.nan, None)

print(external_variables_per_country_and_school_holiday_zone)
#with pd.option_context('display.max_rows', None, 'display.max_columns', None): print(external_variables_per_country_and_school_holiday_zone.loc[external_variables_per_country_and_school_holiday_zone['School_holiday_zone']=='DE-BB'])
query_dwh.post_data_table(environment=environment_push_data
                          ,table_name_dwh='[ds_generic].[ExternalVariables_Country_SchoolHolidayZone]'
                          ,col_names=external_variables_per_country_and_school_holiday_zone.columns
                          ,df=external_variables_per_country_and_school_holiday_zone
                          ,current_time=current_time)